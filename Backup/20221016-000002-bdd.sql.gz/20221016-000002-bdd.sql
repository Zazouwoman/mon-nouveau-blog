--
-- PostgreSQL database dump
--

-- Dumped from database version 11.16 (Debian 11.16-0+deb10u1)
-- Dumped by pg_dump version 11.16 (Debian 11.16-0+deb10u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: admin_interface_theme; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.admin_interface_theme (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    active boolean NOT NULL,
    title character varying(50) NOT NULL,
    title_visible boolean NOT NULL,
    logo character varying(100) NOT NULL,
    logo_visible boolean NOT NULL,
    css_header_background_color character varying(10) NOT NULL,
    title_color character varying(10) NOT NULL,
    css_header_text_color character varying(10) NOT NULL,
    css_header_link_color character varying(10) NOT NULL,
    css_header_link_hover_color character varying(10) NOT NULL,
    css_module_background_color character varying(10) NOT NULL,
    css_module_text_color character varying(10) NOT NULL,
    css_module_link_color character varying(10) NOT NULL,
    css_module_link_hover_color character varying(10) NOT NULL,
    css_module_rounded_corners boolean NOT NULL,
    css_generic_link_color character varying(10) NOT NULL,
    css_generic_link_hover_color character varying(10) NOT NULL,
    css_save_button_background_color character varying(10) NOT NULL,
    css_save_button_background_hover_color character varying(10) NOT NULL,
    css_save_button_text_color character varying(10) NOT NULL,
    css_delete_button_background_color character varying(10) NOT NULL,
    css_delete_button_background_hover_color character varying(10) NOT NULL,
    css_delete_button_text_color character varying(10) NOT NULL,
    list_filter_dropdown boolean NOT NULL,
    related_modal_active boolean NOT NULL,
    related_modal_background_color character varying(10) NOT NULL,
    related_modal_rounded_corners boolean NOT NULL,
    logo_color character varying(10) NOT NULL,
    recent_actions_visible boolean NOT NULL,
    favicon character varying(100) NOT NULL,
    related_modal_background_opacity character varying(5) NOT NULL,
    env_name character varying(50) NOT NULL,
    env_visible_in_header boolean NOT NULL,
    env_color character varying(10) NOT NULL,
    env_visible_in_favicon boolean NOT NULL,
    related_modal_close_button_visible boolean NOT NULL,
    language_chooser_active boolean NOT NULL,
    language_chooser_display character varying(10) NOT NULL,
    list_filter_sticky boolean NOT NULL,
    form_pagination_sticky boolean NOT NULL,
    form_submit_sticky boolean NOT NULL,
    css_module_background_selected_color character varying(10) NOT NULL,
    css_module_link_selected_color character varying(10) NOT NULL,
    logo_max_height smallint NOT NULL,
    logo_max_width smallint NOT NULL,
    foldable_apps boolean NOT NULL,
    CONSTRAINT admin_interface_theme_logo_max_height_check CHECK ((logo_max_height >= 0)),
    CONSTRAINT admin_interface_theme_logo_max_width_check CHECK ((logo_max_width >= 0))
);


ALTER TABLE public.admin_interface_theme OWNER TO claire;

--
-- Name: admin_interface_theme_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.admin_interface_theme_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_interface_theme_id_seq OWNER TO claire;

--
-- Name: admin_interface_theme_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.admin_interface_theme_id_seq OWNED BY public.admin_interface_theme.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO claire;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO claire;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO claire;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO claire;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO claire;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO claire;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: authentification_user; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.authentification_user (
    id bigint NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    profile_photo character varying(100) NOT NULL
);


ALTER TABLE public.authentification_user OWNER TO claire;

--
-- Name: authentification_user_groups; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.authentification_user_groups (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.authentification_user_groups OWNER TO claire;

--
-- Name: authentification_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.authentification_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.authentification_user_groups_id_seq OWNER TO claire;

--
-- Name: authentification_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.authentification_user_groups_id_seq OWNED BY public.authentification_user_groups.id;


--
-- Name: authentification_user_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.authentification_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.authentification_user_id_seq OWNER TO claire;

--
-- Name: authentification_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.authentification_user_id_seq OWNED BY public.authentification_user.id;


--
-- Name: authentification_user_user_permissions; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.authentification_user_user_permissions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.authentification_user_user_permissions OWNER TO claire;

--
-- Name: authentification_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.authentification_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.authentification_user_user_permissions_id_seq OWNER TO claire;

--
-- Name: authentification_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.authentification_user_user_permissions_id_seq OWNED BY public.authentification_user_user_permissions.id;


--
-- Name: bdd_affaire; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.bdd_affaire (
    id bigint NOT NULL,
    soldee boolean NOT NULL,
    "Type_Dossier" character varying(3) NOT NULL,
    "Indice_Dossier" integer NOT NULL,
    "Ref_Affaire" character varying(50) NOT NULL,
    "Nom_Affaire" character varying(100),
    "Honoraires_Global" numeric(12,2) NOT NULL,
    "Date_Creation" date NOT NULL,
    "Date_Previsionnelle" date,
    "Type_Affaire" character varying(12) NOT NULL,
    "Etat" character varying(8) NOT NULL,
    "ID_Client_Cache_id" bigint,
    "ID_Envoi_Facture_id" bigint,
    "ID_Mission_id" bigint NOT NULL,
    "ID_Payeur_id" bigint,
    "ID_Pilote_id" bigint,
    "Ref_Client" character varying(50) NOT NULL
);


ALTER TABLE public.bdd_affaire OWNER TO claire;

--
-- Name: bdd_affaire_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.bdd_affaire_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bdd_affaire_id_seq OWNER TO claire;

--
-- Name: bdd_affaire_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.bdd_affaire_id_seq OWNED BY public.bdd_affaire.id;


--
-- Name: bdd_attachment; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.bdd_attachment (
    id bigint NOT NULL,
    nom character varying(70) NOT NULL,
    file character varying(100) NOT NULL,
    message_id bigint NOT NULL
);


ALTER TABLE public.bdd_attachment OWNER TO claire;

--
-- Name: bdd_attachment_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.bdd_attachment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bdd_attachment_id_seq OWNER TO claire;

--
-- Name: bdd_attachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.bdd_attachment_id_seq OWNED BY public.bdd_attachment.id;


--
-- Name: bdd_client; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.bdd_client (
    id bigint NOT NULL,
    "Type_Dossier" character varying(3) NOT NULL,
    "Indice_Dossier" integer NOT NULL,
    "Numero_Client" character varying(50) NOT NULL,
    "Denomination_Sociale" character varying(150) NOT NULL,
    "SIRET" character varying(50) NOT NULL,
    "Adresse" character varying(500) NOT NULL,
    "CP" character varying(5) NOT NULL,
    "Ville" character varying(150) NOT NULL,
    "Civilite" character varying(3) NOT NULL,
    "Nom_Representant" character varying(50) NOT NULL,
    "Prenom_Representant" character varying(50) NOT NULL,
    "Tel_Representant" character varying(16) NOT NULL,
    "Email_Representant" character varying(70) NOT NULL
);


ALTER TABLE public.bdd_client OWNER TO claire;

--
-- Name: bdd_client_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.bdd_client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bdd_client_id_seq OWNER TO claire;

--
-- Name: bdd_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.bdd_client_id_seq OWNED BY public.bdd_client.id;


--
-- Name: bdd_compteur_indice; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.bdd_compteur_indice (
    id bigint NOT NULL,
    "Type_Dossier" character varying(3) NOT NULL,
    "Periode" character varying(10) NOT NULL,
    "Compteur" integer NOT NULL
);


ALTER TABLE public.bdd_compteur_indice OWNER TO claire;

--
-- Name: bdd_compteur_indice_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.bdd_compteur_indice_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bdd_compteur_indice_id_seq OWNER TO claire;

--
-- Name: bdd_compteur_indice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.bdd_compteur_indice_id_seq OWNED BY public.bdd_compteur_indice.id;


--
-- Name: bdd_envoi_facture; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.bdd_envoi_facture (
    id bigint NOT NULL,
    "Denomination_Sociale" character varying(150) NOT NULL,
    "Adresse" character varying(500) NOT NULL,
    "CP" character varying(5) NOT NULL,
    "Ville" character varying(150) NOT NULL,
    "Civilite" character varying(3) NOT NULL,
    "Nom_Contact" character varying(50) NOT NULL,
    "Prenom_Contact" character varying(50) NOT NULL,
    "Tel_Contact" character varying(16) NOT NULL,
    "Email_Contact" character varying(70) NOT NULL,
    "Mode_Paiement" character varying(20) NOT NULL,
    "Delais_Paiement" character varying(3) NOT NULL,
    "Fin_Mois" character varying(3) NOT NULL,
    "Modalites_Paiement" text NOT NULL
);


ALTER TABLE public.bdd_envoi_facture OWNER TO claire;

--
-- Name: bdd_envoi_facture_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.bdd_envoi_facture_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bdd_envoi_facture_id_seq OWNER TO claire;

--
-- Name: bdd_envoi_facture_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.bdd_envoi_facture_id_seq OWNED BY public.bdd_envoi_facture.id;


--
-- Name: bdd_envoi_offre; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.bdd_envoi_offre (
    id bigint NOT NULL,
    "Denomination_Sociale" character varying(50) NOT NULL,
    "Adresse" character varying(500) NOT NULL,
    "CP" character varying(5) NOT NULL,
    "Ville" character varying(150) NOT NULL,
    "Civilite" character varying(3) NOT NULL,
    "Nom_Contact" character varying(50) NOT NULL,
    "Prenom_Contact" character varying(50) NOT NULL,
    "Tel_Contact" character varying(16) NOT NULL,
    "Email_Contact" character varying(70) NOT NULL
);


ALTER TABLE public.bdd_envoi_offre OWNER TO claire;

--
-- Name: bdd_envoi_offre_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.bdd_envoi_offre_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bdd_envoi_offre_id_seq OWNER TO claire;

--
-- Name: bdd_envoi_offre_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.bdd_envoi_offre_id_seq OWNED BY public.bdd_envoi_offre.id;


--
-- Name: bdd_facture; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.bdd_facture (
    id bigint NOT NULL,
    deja_validee boolean NOT NULL,
    deja_envoyee boolean NOT NULL,
    deja_payee boolean NOT NULL,
    "Numero_Facture" character varying(50) NOT NULL,
    "Indice_Facture" integer NOT NULL,
    "Nom_Affaire" character varying(100),
    "Descriptif" text NOT NULL,
    "Montant_Facture_HT" numeric(12,2) NOT NULL,
    "Taux_TVA" character varying(2) NOT NULL,
    "Date_Facture" date NOT NULL,
    "Facture_Avoir" character varying(10) NOT NULL,
    "Etat" character varying(8) NOT NULL,
    "Etat_Paiement" character varying(8) NOT NULL,
    "Date_Envoi" date NOT NULL,
    "Date_Relance1" date NOT NULL,
    "Date_Relance2" date NOT NULL,
    "Date_Relance3" date NOT NULL,
    "Date_Relance4" date NOT NULL,
    "Date_Relance5" date NOT NULL,
    "Date_Dernier_Rappel" date NOT NULL,
    "Num_Relance" integer NOT NULL,
    "Num_RAR" character varying(25) NOT NULL,
    "Num_RAR_Demeure" character varying(25) NOT NULL,
    "Mode_Paiement" character varying(20) NOT NULL,
    "Delais_Paiement" integer NOT NULL,
    "Fin_Mois" character varying(3) NOT NULL,
    "Modalites_Paiement" text NOT NULL,
    "Denomination_Client" character varying(50) NOT NULL,
    "Adresse_Client" character varying(500) NOT NULL,
    "CP_Client" character varying(5) NOT NULL,
    "Ville_Client" character varying(150) NOT NULL,
    "Civilite_Client" character varying(3) NOT NULL,
    "Nom_Client" character varying(50) NOT NULL,
    "Prenom_Client" character varying(50) NOT NULL,
    "Email_Client" character varying(70) NOT NULL,
    "Denomination_Facture" character varying(50) NOT NULL,
    "Adresse_Facture" character varying(500) NOT NULL,
    "CP_Facture" character varying(5) NOT NULL,
    "Ville_Facture" character varying(150) NOT NULL,
    "Civilite_Facture" character varying(3) NOT NULL,
    "Nom_Facture" character varying(50) NOT NULL,
    "Prenom_Facture" character varying(50) NOT NULL,
    "Email_Facture" character varying(70) NOT NULL,
    "Civilite_Pilote" character varying(3) NOT NULL,
    "Nom_Pilote" character varying(50) NOT NULL,
    "Prenom_Pilote" character varying(50) NOT NULL,
    "Tel_Portable_Pilote" character varying(16) NOT NULL,
    "Email_Pilote" character varying(70) NOT NULL,
    "ID_Affaire_id" bigint NOT NULL,
    "ID_Envoi_Facture_id" bigint,
    "ID_Payeur_id" bigint,
    "ID_Pilote_id" bigint,
    "Date_Relance6" date NOT NULL,
    "Facture_Liee" character varying(20),
    "Num_Suivi" character varying(20) NOT NULL,
    "Ref_Client" character varying(50) NOT NULL
);


ALTER TABLE public.bdd_facture OWNER TO claire;

--
-- Name: bdd_facture_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.bdd_facture_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bdd_facture_id_seq OWNER TO claire;

--
-- Name: bdd_facture_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.bdd_facture_id_seq OWNED BY public.bdd_facture.id;


--
-- Name: bdd_infoemail; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.bdd_infoemail (
    id bigint NOT NULL,
    "From" character varying(70) NOT NULL,
    "To" character varying(70) NOT NULL,
    "Subject" character varying(100) NOT NULL,
    "Message" text NOT NULL,
    "File" character varying(100) NOT NULL,
    "ID_Facture" integer,
    "Type_Action" character varying(100) NOT NULL,
    "RAR" character varying(20),
    "Suivi" character varying(20)
);


ALTER TABLE public.bdd_infoemail OWNER TO claire;

--
-- Name: bdd_infoemail_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.bdd_infoemail_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bdd_infoemail_id_seq OWNER TO claire;

--
-- Name: bdd_infoemail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.bdd_infoemail_id_seq OWNED BY public.bdd_infoemail.id;


--
-- Name: bdd_ingeprev; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.bdd_ingeprev (
    id bigint NOT NULL,
    "Nom" character varying(50) NOT NULL,
    "SIRET" character varying(50) NOT NULL,
    "Adresse" character varying(500) NOT NULL,
    "Complement_Adresse" character varying(500) NOT NULL,
    "CP" character varying(5) NOT NULL,
    "Ville" character varying(150) NOT NULL,
    "Type_Societe" character varying(150) NOT NULL,
    "IBAN" character varying(50) NOT NULL,
    "Code_APE" character varying(150) NOT NULL,
    "Capital" numeric(15,2) NOT NULL,
    "Num_TVA" character varying(150) NOT NULL,
    "Email" character varying(70) NOT NULL,
    "Tel" character varying(16) NOT NULL,
    "Site_Web" character varying(300) NOT NULL,
    "Facebook" character varying(300) NOT NULL,
    "Twitter" character varying(300) NOT NULL,
    "Linkedin" character varying(300) NOT NULL,
    "Cle" character varying(10) NOT NULL,
    "Code_BIC" character varying(20) NOT NULL,
    "Code_Banque" character varying(6),
    "Code_Guichet" character varying(6),
    "Nom_Banque" character varying(100) NOT NULL,
    "Num_Compte" character varying(20),
    "Tel_Banque" character varying(16) NOT NULL,
    logo character varying(100)
);


ALTER TABLE public.bdd_ingeprev OWNER TO claire;

--
-- Name: bdd_ingeprev_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.bdd_ingeprev_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bdd_ingeprev_id_seq OWNER TO claire;

--
-- Name: bdd_ingeprev_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.bdd_ingeprev_id_seq OWNED BY public.bdd_ingeprev.id;


--
-- Name: bdd_offre_mission; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.bdd_offre_mission (
    id bigint NOT NULL,
    "Type_Dossier" character varying(3) NOT NULL,
    "Indice_Dossier" integer NOT NULL,
    "Ref_Mission" character varying(50) NOT NULL,
    "Nom_Mission" character varying(100) NOT NULL,
    "Adresse" character varying(500) NOT NULL,
    "CP" character varying(5) NOT NULL,
    "Ville" character varying(150) NOT NULL,
    "Honoraires_Proposes" numeric(12,2) NOT NULL,
    "Date_Proposition" date NOT NULL,
    "Date_Acceptation" date,
    "Descriptif" text NOT NULL,
    "Etat" character varying(20) NOT NULL,
    "ID_Apporteur_id" bigint,
    "ID_Client_Cache_id" bigint,
    "ID_Envoi_Offre_id" bigint,
    "ID_Payeur_id" bigint,
    "ID_Pilote_id" bigint
);


ALTER TABLE public.bdd_offre_mission OWNER TO claire;

--
-- Name: bdd_offre_mission_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.bdd_offre_mission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bdd_offre_mission_id_seq OWNER TO claire;

--
-- Name: bdd_offre_mission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.bdd_offre_mission_id_seq OWNED BY public.bdd_offre_mission.id;


--
-- Name: bdd_pilote; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.bdd_pilote (
    id bigint NOT NULL,
    "Civilite" character varying(3) NOT NULL,
    "Nom" character varying(50) NOT NULL,
    "Prenom" character varying(50) NOT NULL,
    "Tel_Portable" character varying(16) NOT NULL,
    "Tel_Fixe" character varying(16) NOT NULL,
    "Email" character varying(70) NOT NULL
);


ALTER TABLE public.bdd_pilote OWNER TO claire;

--
-- Name: bdd_pilote_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.bdd_pilote_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bdd_pilote_id_seq OWNER TO claire;

--
-- Name: bdd_pilote_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.bdd_pilote_id_seq OWNED BY public.bdd_pilote.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id bigint NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO claire;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO claire;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO claire;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO claire;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO claire;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO claire;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO claire;

--
-- Name: processes_logbackup; Type: TABLE; Schema: public; Owner: claire
--

CREATE TABLE public.processes_logbackup (
    id bigint NOT NULL,
    dt timestamp with time zone NOT NULL,
    dt_end timestamp with time zone,
    success boolean,
    fichier character varying(255) NOT NULL,
    size integer
);


ALTER TABLE public.processes_logbackup OWNER TO claire;

--
-- Name: processes_logbackup_id_seq; Type: SEQUENCE; Schema: public; Owner: claire
--

CREATE SEQUENCE public.processes_logbackup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.processes_logbackup_id_seq OWNER TO claire;

--
-- Name: processes_logbackup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: claire
--

ALTER SEQUENCE public.processes_logbackup_id_seq OWNED BY public.processes_logbackup.id;


--
-- Name: admin_interface_theme id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.admin_interface_theme ALTER COLUMN id SET DEFAULT nextval('public.admin_interface_theme_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: authentification_user id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.authentification_user ALTER COLUMN id SET DEFAULT nextval('public.authentification_user_id_seq'::regclass);


--
-- Name: authentification_user_groups id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.authentification_user_groups ALTER COLUMN id SET DEFAULT nextval('public.authentification_user_groups_id_seq'::regclass);


--
-- Name: authentification_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.authentification_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.authentification_user_user_permissions_id_seq'::regclass);


--
-- Name: bdd_affaire id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_affaire ALTER COLUMN id SET DEFAULT nextval('public.bdd_affaire_id_seq'::regclass);


--
-- Name: bdd_attachment id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_attachment ALTER COLUMN id SET DEFAULT nextval('public.bdd_attachment_id_seq'::regclass);


--
-- Name: bdd_client id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_client ALTER COLUMN id SET DEFAULT nextval('public.bdd_client_id_seq'::regclass);


--
-- Name: bdd_compteur_indice id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_compteur_indice ALTER COLUMN id SET DEFAULT nextval('public.bdd_compteur_indice_id_seq'::regclass);


--
-- Name: bdd_envoi_facture id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_envoi_facture ALTER COLUMN id SET DEFAULT nextval('public.bdd_envoi_facture_id_seq'::regclass);


--
-- Name: bdd_envoi_offre id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_envoi_offre ALTER COLUMN id SET DEFAULT nextval('public.bdd_envoi_offre_id_seq'::regclass);


--
-- Name: bdd_facture id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_facture ALTER COLUMN id SET DEFAULT nextval('public.bdd_facture_id_seq'::regclass);


--
-- Name: bdd_infoemail id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_infoemail ALTER COLUMN id SET DEFAULT nextval('public.bdd_infoemail_id_seq'::regclass);


--
-- Name: bdd_ingeprev id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_ingeprev ALTER COLUMN id SET DEFAULT nextval('public.bdd_ingeprev_id_seq'::regclass);


--
-- Name: bdd_offre_mission id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_offre_mission ALTER COLUMN id SET DEFAULT nextval('public.bdd_offre_mission_id_seq'::regclass);


--
-- Name: bdd_pilote id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_pilote ALTER COLUMN id SET DEFAULT nextval('public.bdd_pilote_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: processes_logbackup id; Type: DEFAULT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.processes_logbackup ALTER COLUMN id SET DEFAULT nextval('public.processes_logbackup_id_seq'::regclass);


--
-- Data for Name: admin_interface_theme; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.admin_interface_theme (id, name, active, title, title_visible, logo, logo_visible, css_header_background_color, title_color, css_header_text_color, css_header_link_color, css_header_link_hover_color, css_module_background_color, css_module_text_color, css_module_link_color, css_module_link_hover_color, css_module_rounded_corners, css_generic_link_color, css_generic_link_hover_color, css_save_button_background_color, css_save_button_background_hover_color, css_save_button_text_color, css_delete_button_background_color, css_delete_button_background_hover_color, css_delete_button_text_color, list_filter_dropdown, related_modal_active, related_modal_background_color, related_modal_rounded_corners, logo_color, recent_actions_visible, favicon, related_modal_background_opacity, env_name, env_visible_in_header, env_color, env_visible_in_favicon, related_modal_close_button_visible, language_chooser_active, language_chooser_display, list_filter_sticky, form_pagination_sticky, form_submit_sticky, css_module_background_selected_color, css_module_link_selected_color, logo_max_height, logo_max_width, foldable_apps) FROM stdin;
2	USWDS	t	INGEPREV	f	admin-interface/logo/Logo-Ingeprev-WhiteTxt.png	t	#112E51	#FFFFFF	#FFFFFF	#FFFFFF	#E1F3F8	#205493	#FFFFFF	#FFFFFF	#E1F3F8	t	#205493	#0071BC	#205493	#112E51	#FFFFFF	#CD2026	#981B1E	#FFFFFF	f	t	#000000	t	#FFFFFF	t		0.8		t	#E74C3C	t	t	t	code	t	f	f	#FFFFCC	#FFFFFF	100	400	t
1	Django	f	Django administration	t		t	#0C4B33	#F5DD5D	#44B78B	#FFFFFF	#C9F0DD	#44B78B	#FFFFFF	#FFFFFF	#C9F0DD	t	#0C3C26	#156641	#0C4B33	#0C3C26	#FFFFFF	#BA2121	#A41515	#FFFFFF	t	t	#000000	t	#FFFFFF	t		0.3		t	#E74C3C	t	t	t	code	t	f	f	#FFFFCC	#FFFFFF	100	400	t
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.auth_group (id, name) FROM stdin;
2	Comptable
1	Gerant
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
1	1	25
2	1	26
3	1	27
4	1	28
5	1	29
6	1	30
7	1	31
8	1	32
9	1	33
10	1	34
11	1	36
12	1	37
13	1	38
14	1	39
15	1	40
16	1	41
17	1	42
18	1	43
19	1	44
20	1	45
21	1	46
22	1	47
23	1	48
24	1	49
25	1	50
26	1	51
27	1	52
28	1	53
29	1	54
30	1	55
31	1	56
32	1	57
33	1	58
34	1	59
35	1	60
36	1	61
37	1	62
38	1	63
39	1	64
40	1	65
41	1	66
43	1	68
44	2	58
45	2	60
46	1	76
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add Theme	1	add_theme
2	Can change Theme	1	change_theme
3	Can delete Theme	1	delete_theme
4	Can view Theme	1	view_theme
5	Can add log entry	2	add_logentry
6	Can change log entry	2	change_logentry
7	Can delete log entry	2	delete_logentry
8	Can view log entry	2	view_logentry
9	Can add permission	3	add_permission
10	Can change permission	3	change_permission
11	Can delete permission	3	delete_permission
12	Can view permission	3	view_permission
13	Can add group	4	add_group
14	Can change group	4	change_group
15	Can delete group	4	delete_group
16	Can view group	4	view_group
17	Can add content type	5	add_contenttype
18	Can change content type	5	change_contenttype
19	Can delete content type	5	delete_contenttype
20	Can view content type	5	view_contenttype
21	Can add session	6	add_session
22	Can change session	6	change_session
23	Can delete session	6	delete_session
24	Can view session	6	view_session
25	Can add affaire	7	add_affaire
26	Can change affaire	7	change_affaire
27	Can delete affaire	7	delete_affaire
28	Can view affaire	7	view_affaire
29	Can add client	8	add_client
30	Can change client	8	change_client
31	Can delete client	8	delete_client
32	Can view client	8	view_client
33	Can add compteur_ indice	9	add_compteur_indice
34	Can change compteur_ indice	9	change_compteur_indice
35	Can delete compteur_ indice	9	delete_compteur_indice
36	Can view compteur_ indice	9	view_compteur_indice
37	Can add envoi_ facture	10	add_envoi_facture
38	Can change envoi_ facture	10	change_envoi_facture
39	Can delete envoi_ facture	10	delete_envoi_facture
40	Can view envoi_ facture	10	view_envoi_facture
41	Can add envoi_ offre	11	add_envoi_offre
42	Can change envoi_ offre	11	change_envoi_offre
43	Can delete envoi_ offre	11	delete_envoi_offre
44	Can view envoi_ offre	11	view_envoi_offre
45	Can add info email	12	add_infoemail
46	Can change info email	12	change_infoemail
47	Can delete info email	12	delete_infoemail
48	Can view info email	12	view_infoemail
49	Can add pilote	13	add_pilote
50	Can change pilote	13	change_pilote
51	Can delete pilote	13	delete_pilote
52	Can view pilote	13	view_pilote
53	Can add offre_ mission	14	add_offre_mission
54	Can change offre_ mission	14	change_offre_mission
55	Can delete offre_ mission	14	delete_offre_mission
56	Can view offre_ mission	14	view_offre_mission
57	Can add facture	15	add_facture
58	Can change facture	15	change_facture
59	Can delete facture	15	delete_facture
60	Can view facture	15	view_facture
61	Can add attachment	16	add_attachment
62	Can change attachment	16	change_attachment
63	Can delete attachment	16	delete_attachment
64	Can view attachment	16	view_attachment
65	Can add ingeprev	17	add_ingeprev
66	Can change ingeprev	17	change_ingeprev
67	Can delete ingeprev	17	delete_ingeprev
68	Can view ingeprev	17	view_ingeprev
69	Can add user	18	add_user
70	Can change user	18	change_user
71	Can delete user	18	delete_user
72	Can view user	18	view_user
73	Can add log backup	19	add_logbackup
74	Can change log backup	19	change_logbackup
75	Can delete log backup	19	delete_logbackup
76	Can view log backup	19	view_logbackup
\.


--
-- Data for Name: authentification_user; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.authentification_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, profile_photo) FROM stdin;
5	pbkdf2_sha256$320000$aH38lj6NvuSU2dsd9MuipY$areXPIJRxS/tiaNiuupOO6fzUtbFRktDgGYi+N3mL9I=	2022-09-30 15:48:22.034891+00	f	COMPTABLE	Claire	VEYDT	claireveydt@gmail.com	t	t	2022-08-29 13:28:03+00	
3	pbkdf2_sha256$320000$RWGIy5I1bruHNuZBfX3cvB$dqGyeNpiWbNm6hjXNG/2l6YuszyH8oKgPKf79SzAe9Q=	2022-10-03 13:02:53.846319+00	f	FS	Frédéric	SIMON	fs@ingeprev.com	t	t	2022-07-02 14:37:11+00	
6	pbkdf2_sha256$320000$O7J8UXgNN5V69kXnTH9SYT$NqHJByA3wygDCmtt8VWLNG0/SMUDKkseYwED8N3dcF8=	2022-10-10 09:19:38.017023+00	t	gbenoit			painbiogy@gmail.com	t	t	2022-08-29 16:40:15.592643+00	
2	pbkdf2_sha256$320000$VJAOeMf4GQcY7m8JevqsMD$lrttDNDGaH6aAmNNCWhw61qUKHmRjoot2ywDgfyIkt8=	2022-10-10 17:25:22.545746+00	f	JMG	Jean-Michel	GAUDY		t	t	2022-07-02 14:36:29+00	
1	pbkdf2_sha256$320000$YVSS0yqxIxrbmWbxoAhmqC$enjJ/Tkl1hy+UxIHDaAW5xCoac3nwY7bQKAzwvdV7tc=	2022-10-12 16:06:00.228454+00	t	cgaudy			gaudy.claire@gmail.com	t	t	2022-07-02 14:33:46.080569+00	
\.


--
-- Data for Name: authentification_user_groups; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.authentification_user_groups (id, user_id, group_id) FROM stdin;
1	2	1
2	3	1
4	5	2
\.


--
-- Data for Name: authentification_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.authentification_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: bdd_affaire; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.bdd_affaire (id, soldee, "Type_Dossier", "Indice_Dossier", "Ref_Affaire", "Nom_Affaire", "Honoraires_Global", "Date_Creation", "Date_Previsionnelle", "Type_Affaire", "Etat", "ID_Client_Cache_id", "ID_Envoi_Facture_id", "ID_Mission_id", "ID_Payeur_id", "ID_Pilote_id", "Ref_Client") FROM stdin;
4	f	A	2	A-2022100002	Assembly - 27 Sampaix	17400.00	2022-10-08	2022-12-31	C	EC	4	4	3	3	1	
5	f	A	3	A-2022100003	BETC - Studio BroadCast	5985.00	2022-10-10	2022-12-15	C	EC	19	5	16	18	1	
2	f	A	1	A-2022090001	Orfeo - One Monceau	31800.00	2022-09-13	2022-10-27	C	EC	6	2	5	7	1	
3	f	A	1	A-2022100001	Orfeo - Blancs Manteaux	18600.00	2022-10-03	2022-11-30	C	EC	6	3	10	11	1	38 BM - Préventionniste
\.


--
-- Data for Name: bdd_attachment; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.bdd_attachment (id, nom, file, message_id) FROM stdin;
\.


--
-- Data for Name: bdd_client; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.bdd_client (id, "Type_Dossier", "Indice_Dossier", "Numero_Client", "Denomination_Sociale", "SIRET", "Adresse", "CP", "Ville", "Civilite", "Nom_Representant", "Prenom_Representant", "Tel_Representant", "Email_Representant") FROM stdin;
2	C	1	C-2022090001	SOGELYM DIXENCE	488 091 968 RCS LYON	5, rue de la Baume	75008	PARIS	M.	BAYLE	Jean-Baptiste		jean-baptiste.bayle@sogelym-dixence.fr
4	C	3	C-2022090003	ASSEMBLY		79, boulevard MALESHERBES	75008	PARIS					
5	C	4	C-2022090004	BNP PARIBAS REAL ESTATE									
7	C	6	C-2022090006	SCI PREIM ONE MONCEAU									
8	C	7	C-2022090007	SCI 69 CHARONNE Représentée par Batipart Immo Europe Management France		28, avenue Victor HUGO	75116	PARIS					
9	C	8	C-2022090008	TS CRISTAL SCI		115, rue Réaumur	75002	PARIS					
10	C	9	C-2022090009	TISHMAN SPEYER		115, rue Réaumur	75002	PARIS					
12	C	11	C-2022090011	VILLAGE 7 DEFENSE		7, place du Chancelier Adenauer	75016	PARIS					
13	C	12	C-2022090012	URW		7, place du Chancelier Adenauer	75016	PARIS					
14	C	13	C-2022090013	SAS BERCY LUMIERE S/C SEFAL PROPERTY		134, rue Danton	92300	Levallois-Perret					
15	C	14	C-2022090014	SAS BERCY LUMIERE S/C MAYA Advisors		13, rue Saint-Honoré	7800	VERSAILLES					
16	C	15	C-2022090015	Ministère de la Justice									
17	C	16	C-2022090016	2BDM		60-62, rue d'Hauteville	75010	PARIS					
18	C	17	C-2022090017	Général Pop		3, rue de l'ancien canal	93500	PANTIN					
19	C	18	C-2022090018	BETC		3, rue de l'ancien canal	93500	PANTIN					
20	C	19	C-2022090019	CHROME		5, avenue du Pont Royal	94230	CACHAN					
21	C	20	C-2022090020	F8 Architecteure		40, avenue des Terroirs de France	75012	PARIS					
22	C	1	C-2022100001	Ministère de l’Intérieur DEPAFI / SDAI / BGSAC		40, avenue des Terroirs de France	75012	PARIS					
11	C	10	C-2022090010	38 rue des Blancs Manteaux SCI		3, rue du Colonel Moll	75004	Paris	Mme	SEZALORY	Morgane		
23	C	2	C-2022100002	Chartier Dalix		27 rue Popincourt	75011	Paris	M.	BORSARI	ALEXANDRE	0679214085	alexandre.borsari@chartier-dalix.com
6	C	5	C-2022090005	ORFEO Développement		14, rue de BASSANO	75116	PARIS					
24	C	3	C-2022100003	EGIS		4 rue Dolorès Ibarruri	93100	MONTREUIL	Mme	LATOUR	Isabelle	0672665010	Isabelle.LATOUR@egis-group.com
25	C	4	C-2022100004	CSD & ASSOCIES									
3	C	2	C-2022090002	SNC DU 27 RUE LUCIEN SAMPAIX									
26	C	5	C-2022100005	SCI 74 Champs-Elysées		74 avenue des Champs-Elysées	75008	PARIS	Mme	VEYRIER	Priscille	0638849213	Priscille.VEYRIER@axa-im.com
27	C	6	C-2022100006	BNPPI		50 Cours de l'Ile Seguin	92650	Boulogne Billancourt Cedex					
28	C	7	C-2022100007	STAM EUROPE		18/20 place de la Madeleine	75008	PARIS	M.	De Saqui de Sannes	Antoine	0695108547	antoine.desaqui@stam-europe.com
\.


--
-- Data for Name: bdd_compteur_indice; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.bdd_compteur_indice (id, "Type_Dossier", "Periode", "Compteur") FROM stdin;
10	C	202210	7
11	OM	202210	10
9	A	202209	1
7	C	202209	20
8	OM	202209	16
12	A	202210	3
\.


--
-- Data for Name: bdd_envoi_facture; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.bdd_envoi_facture (id, "Denomination_Sociale", "Adresse", "CP", "Ville", "Civilite", "Nom_Contact", "Prenom_Contact", "Tel_Contact", "Email_Contact", "Mode_Paiement", "Delais_Paiement", "Fin_Mois", "Modalites_Paiement") FROM stdin;
2	SCI PREIM ONE MONCEAU									VI	30	Oui	
3	ORFEO Développement	14, rue de BASSANO	75116	PARIS	M.	MULLIE	Henri		hm@orfeo-developpement.com	VI	60	Non	Rappeler la référence suivante : 38 BM - Préventionniste\r\n\r\nSelon LC ORFEO Développement n°LC-38_BM C  22 - 010
4	ASSEMBLY	79, boulevard Malesherbes	75008	PARIS						VI	60	Non	Factures à envoyer par mail et par courrier à Assembly.\r\nFacturation selon Lettre de Commande en date du 27 septembre 2022 :\r\n- 80% à la remise des documents\r\n- 20% à l'obtention du PC\r\n\r\nPaiement à 45 jours calendaires par virement
5	Général Pop	3, rue de l'ancien canal	93500	PANTIN						VI	60	Non	ATTENTION Joindre l'OM validée à chaque facture
\.


--
-- Data for Name: bdd_envoi_offre; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.bdd_envoi_offre (id, "Denomination_Sociale", "Adresse", "CP", "Ville", "Civilite", "Nom_Contact", "Prenom_Contact", "Tel_Contact", "Email_Contact") FROM stdin;
1	ASSEMBLY	79, boulevard Malesherbes	75008	PARIS	M.	ROUER	Bastien		brouer@assembly.fr
2	ORFEO Développement	14, rue de Bassano	75116	PARIS					
3	TISHMAN SPEYER	33 rue Vivienne	75002	Paris	Mme	BREVET	Emeline	0772779205	EBrevet@TishmanSpeyer.fr
4	2BDM	60-62, rue d'Hauteville	75010	PARIS					
\.


--
-- Data for Name: bdd_facture; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.bdd_facture (id, deja_validee, deja_envoyee, deja_payee, "Numero_Facture", "Indice_Facture", "Nom_Affaire", "Descriptif", "Montant_Facture_HT", "Taux_TVA", "Date_Facture", "Facture_Avoir", "Etat", "Etat_Paiement", "Date_Envoi", "Date_Relance1", "Date_Relance2", "Date_Relance3", "Date_Relance4", "Date_Relance5", "Date_Dernier_Rappel", "Num_Relance", "Num_RAR", "Num_RAR_Demeure", "Mode_Paiement", "Delais_Paiement", "Fin_Mois", "Modalites_Paiement", "Denomination_Client", "Adresse_Client", "CP_Client", "Ville_Client", "Civilite_Client", "Nom_Client", "Prenom_Client", "Email_Client", "Denomination_Facture", "Adresse_Facture", "CP_Facture", "Ville_Facture", "Civilite_Facture", "Nom_Facture", "Prenom_Facture", "Email_Facture", "Civilite_Pilote", "Nom_Pilote", "Prenom_Pilote", "Tel_Portable_Pilote", "Email_Pilote", "ID_Affaire_id", "ID_Envoi_Facture_id", "ID_Payeur_id", "ID_Pilote_id", "Date_Relance6", "Facture_Liee", "Num_Suivi", "Ref_Client") FROM stdin;
\.


--
-- Data for Name: bdd_infoemail; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.bdd_infoemail (id, "From", "To", "Subject", "Message", "File", "ID_Facture", "Type_Action", "RAR", "Suivi") FROM stdin;
\.


--
-- Data for Name: bdd_ingeprev; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.bdd_ingeprev (id, "Nom", "SIRET", "Adresse", "Complement_Adresse", "CP", "Ville", "Type_Societe", "IBAN", "Code_APE", "Capital", "Num_TVA", "Email", "Tel", "Site_Web", "Facebook", "Twitter", "Linkedin", "Cle", "Code_BIC", "Code_Banque", "Code_Guichet", "Nom_Banque", "Num_Compte", "Tel_Banque", logo) FROM stdin;
1	INGEPREV	91872731400018	10 avenue Kléber		75116	PARIS	S.A.S.	FR7630066109590002037440281		5000.00		contact@ingeprev.com						81	CMCIFRPP	30066	10959	Crédit Industriel et Commercial	00020374402	0141161669	images/Logo-Ingeprev2.jpg
\.


--
-- Data for Name: bdd_offre_mission; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.bdd_offre_mission (id, "Type_Dossier", "Indice_Dossier", "Ref_Mission", "Nom_Mission", "Adresse", "CP", "Ville", "Honoraires_Proposes", "Date_Proposition", "Date_Acceptation", "Descriptif", "Etat", "ID_Apporteur_id", "ID_Client_Cache_id", "ID_Envoi_Offre_id", "ID_Payeur_id", "ID_Pilote_id") FROM stdin;
9	OM	8	OM-2022090008	Tour Cristal / Diamond	7-15, quai André Citroën	75015	PARIS	30000.00	2022-09-10	\N	Phases PRO/DCE + PCM + EXE + AMO CdS	ATT	\N	10	\N	9	1
11	OM	10	OM-2022090010	URW - Village 7	Cours Valmy	92800	PUTEAUX	17400.00	2022-09-11	\N	URW Rénovation de l'immeuble Village 7 cours Valmy La Défense.\r\nPhase APS/ PAD / PC.	ATT	\N	13	\N	\N	1
2	OM	1	OM-2022090001	AMO Accessibilité Campus de Sciences Po	1, place Saint Thomas d'Aquin	75007	PARIS	600.00	2022-09-07	\N	Mission d'Assistance à Maîtrise d'Ouvrage :\r\nParticipation à une réunion d'échange avec Sciences Po au sujet de l'accessibilité des personnes en situation de handicap.	ATT	\N	\N	\N	2	1
4	OM	3	OM-2022090003	Orfeo - Austerlitz - Faisa Preneur	50-52, avenue Pierre Mendès France / 41-49, quai d'Austerlitz	75013	PARIS	5400.00	2022-09-08	\N	La mission de conseil en sécurité incendie et en accessibilité des personnes en situation de handicap a été confiée au bureau d’études CASSO et Associés. \r\n\r\nLe projet objet de la présente offre de mission concerne uniquement la faisabilité des aménagements d’un preneur potentiel.	ATT	\N	6	2	5	1
7	OM	6	OM-2022090006	Orfeo - Murmure	67-69, boulevard de Charonne	75011	PARIS	10200.00	2022-09-10	\N	Murmure phase PRO2/DCE (3 k€) et phase EXE (7,2 k€)\r\nMissions optionnelles :\r\n- AMO CdS (6,6 k€)\r\n- Aménagement coques commerciales (3 k€ par coque)	ATT	\N	6	2	8	1
8	OM	7	OM-2022090007	Orfeo - Faisabilité Tour Blanche	34, place des Corolles	92400	COURBEVOIE	7200.00	2022-09-10	\N	La tour Blanche (ancienne tour Aquitaine, puis tour AIG et tour Chartis) est un IGH de bureaux situé 32, place des COROLLES 92400 Courbevoie (Paris la Défense). \r\n\r\nÉdifiée en 1967 par le cabinet d'architectes Les Frères Arsène-Henry, elle appartient à la première génération des tours de La Défense : sa hauteur respecte la hauteur standard d'alors, qui était de 100 m.\r\n\r\nRénovée partiellement en 2004, elle entre de nouveau en rénovation de juillet 2012 à mars 2014.\r\n\r\nLa tour à R+27 étages développe une surface d’environ 26 000 m². \r\n\r\nLe propriétaire actuel, Perella Weinberg Partners, a l’intention de procéder à une nouvelle réhabilitation de l’IGH.	ATT	\N	\N	\N	6	1
12	OM	11	OM-2022090011	Lumière - RIE "La Source"	40, avenue des Terroirs de France	75012	PARIS	6600.00	2022-09-11	\N	Lumière - RIE "La Source"	ATT	\N	\N	\N	14	1
5	OM	4	OM-2022090004	Orfeo - One Monceau	3, avenue Hoche	75116	PARIS	31800.00	2022-09-08	2022-09-13	Phase APS / PC / APD signées pour 31 800 € HT\r\nReste 7 200 € pour la phase PRO/DCE (pas encore de lettre de commande)	ACC	\N	6	2	7	1
6	OM	5	OM-2022090005	Hôtel Logistique à Colombes - THEOP	32 avenue Kleber	92025	colombes	21600.00	2022-09-09	\N	Il s’agit d’une opération de démolition/reconstruction, avec conservation de l’infrastructure, afin de créer un hôtel multi-activités comprenant de la logistique, de l’activités et des bureaux, le tout se développant sur environ 23000 m² de SDP répartis sur 5 niveaux.\r\n\r\nLe planning de l’opération est le suivant :\r\n\r\n\tPhase APS / PC  de mi-septembre à fin novembre 2022,\r\n\tPhase APD de mi-novembre à mi-janvier 2023,\r\n\tPhase PRO/DCE de mi-janvier à mi-mars 2023,\r\n\tPhase exécution sur 18 mois à compter de l’été 2023.\r\n\r\n\r\nLe montant prévisionnel des travaux est de 35M€.	ATT	\N	\N	\N	\N	3
3	OM	2	OM-2022090002	Assembly - 27 Sampaix	27, rue Lucien SAMPEIX	75010	PARIS	17400.00	2022-09-08	2022-10-08	Le projet vise à rénover de façon globale un immeuble de bureaux sis 27, rue Lucien Sampaix Paris 10ème qui développe une surface d’environ 1750 m² SDP.\r\n\r\nL’objectif final est d’y aménager un Etablissement Recevant du Public du 1er groupe (3ème ou 4ème catégorie). Les locaux seront livrés non aménagés.\r\n\r\nLe montant prévisionnel des travaux est de 3 160 800 € HT (hors curage, désamiantage, déplombage et honoraires).\r\n\r\nLe planning des études n’est pas encore arrêté à ce stade. Il est actuellement envisagé de déposer une demande d’autorisation ERP avant la fin de l’année 2022.	ACC	\N	4	1	3	1
10	OM	9	OM-2022090009	Orfeo - Blancs Manteaux	38, rue des Blancs Manteaux	75004	PARIS	18600.00	2022-09-10	2022-10-03	Phase Esquisse / APS / PC	ACC	\N	6	2	11	1
14	OM	13	OM-2022090013	PdJ - B5 Culture	10, boulevard de la Cité	75001	PARIS	27600.00	2022-09-11	\N	PdJ Ile de la cité - Bâtiment B5 - Périmètre Culture (Sainte chapelle et Conciergerie).\r\n\r\nATTENTION Tableau de décomposition des Honoraires envoyé par 2BDM le 05/10/2022 avec un total \r\n\r\nMission SI à 24 600 € HT au total :\r\n- 13800 € en AVP\r\n- 3600 € en PRO\r\n+ 7200€ de mission complémentaire avec 6000 en VISA et 1200 en AOR\r\n\r\n+ Mission PMR à 26 900€ HT :\r\n- 15000 en AVP\r\n- 4200 en PRO\r\n- 4200 en EXE\r\n- 3500 en AOR	ATT	\N	17	\N	16	1
13	OM	12	OM-2022090012	Lumière - Atrium	40, avenue des Terroirs de France	75012	PARIS	6200.00	2022-09-11	\N	Lumière - Atrium	ATT	\N	\N	\N	15	1
17	OM	16	OM-2022090016	Hekla - Aménagements F8 / Chrome	rue de la demi-lune	92800	Puteaux	15000.00	2022-09-26	\N	Aménagements F8/Chrome de la tour Hekla (RDC Haut et Bas, R+2, R+5 et R+47/48).	ATT	\N	21	\N	20	1
18	OM	1	OM-2022100001	Lumière - MINT R+2 Enclave Garonne	40, avenue des Terroirs de France	75012	PARIS	3300.00	2022-10-02	\N	Aménagement de 180 m² de bureaux au R+2 (niveau 52,72 NVP) de l’aile nord (ex-enclave Garonne) pour le compte de Ministère de l’Intérieur	ATT	\N	21	\N	22	1
19	OM	2	OM-2022100002	L'OREAL CLICHY CES A	41 rue Martre	92117	CLICHY	22200.00	2022-10-03	\N	Offre transmise en phase concours	ATT	23	\N	\N	\N	3
15	OM	14	OM-2022090014	NOVA VILLEJUIF - TISHMAN SPEYER	145-153 Boulevard Maxime Gorki	94800	Villejuif	18000.00	2022-09-21	\N	L’établissement concerné par la présente opération relève du code du travail et est constitué par deux corps de bâtiment : le bâtiment 1 et le bâtiment 2.\r\n\r\nCette mission s’inscrit dans le cadre d’une prise à bail d’une partie du bâtiment 1 par EFREI pour une activité de type R (école d’ingénieurs).\r\n\r\nLes points clés de cette prise à bail :\r\n\r\n\tImplantation de l’activité du RDC au R+4 du bâtiment 1,\r\n\tEffectif total de l’ordre de 2000 personnes, l’effectif total du bâtiment 1 restera inférieur à 2500 personnes,\r\n\tActivité classée ERP de type R de 1ère catégorie.\r\n\r\nDu fait de l’insertion de cette activité, l’ensemble immobilier abrite désormais trois zones distinctes :\r\n\r\n\tUne activité de bureaux au sein du bâtiment 2,\r\n\tUne activité accessible au public de type R du RDC au R+4 du bâtiment 1,\r\n\tUne activité de bureaux de R+5 au R+7 du bâtiment 1.\r\n\r\nLe parc de stationnement n’est pas impacté par la présente opération.\r\n\r\nL’ensemble immobilier constitue un unique établissement qui doit donc être reclassé en ERP de première catégorie avec activité de type R.\r\n\r\nLe planning de l’opération est le suivant :\r\n\r\n\tPhase faisabilité jusque mi-septembre\r\n\tDépôt du dossier PC à fin septembre,\r\n\tPhase APD de octobre à décembre,\r\n\tPhase PRO/DCE de décembre à mars 2023,\r\n\tPhase exécution sur 6 mois à compter du printemps 2023.\r\n\r\nIl s’agit de la phase « coque » de ce reclassement. Les travaux preneur feront l’objet du dépôt ulté-rieur d’un dossier d’aménagement.	ATT	\N	\N	3	10	3
20	OM	3	OM-2022100003	ORFEO - Inspire Puteaux - Due Diligence	46-52, rue Arago	92800	PUTEAUX	3000.00	2022-10-05	\N	Due Diligence Immeuble "Inspire" à Puteaux	ATT	\N	\N	\N	6	1
21	OM	4	OM-2022100004	EGIS - Projet MARIGNAN MONTREUIL	94b rue Marceau / 89 rue Robespierre	93100	MONTREUIL	4800.00	2022-10-07	\N	Uniquement phase PC	ATT	25	\N	\N	24	3
22	OM	5	OM-2022100005	PdJ - B5 Justice	10, boulevard du Palais	75001	PARIS	51500.00	2022-10-08	\N	Palais de Justice - Bâtiment B5 : périmètre Justice	ATT	\N	\N	4	16	1
23	OM	6	OM-2022100006	Orfeo - Rives de Seine - GH 65	68-76, quai de la Rapée	75012	PARIS	7800.00	2022-10-08	\N	Dossier GH 65 de la tour Rives de Seine\r\n- Tranche ferme : 4200 €\r\n- Tranche conditionnelle : 3600 €	ATT	\N	\N	\N	6	1
16	OM	15	OM-2022090015	BETC - Studio BroadCast	3, rue de l'ancien canal	93500	PANTIN	5985.00	2022-09-26	2022-10-10	Aménagement du studio BroadCast	ACC	\N	19	\N	18	1
24	OM	7	OM-2022100007	AXA - 74 avenue des Champs-Elysées	74 avenue des Champs-Elysées	75008	PARIS	6600.00	2022-10-11	\N	AUDIT & FAISABILITE reclassement en type O	ATT	\N	\N	\N	26	3
25	OM	8	OM-2022100008	CACHAN PLURIELS	Quartier de la gare Arceuil-Cachan	94230	CACHAN	86400.00	2022-10-13	\N	Découpage en 6 PC - Phases APS à PRO DCE	ATT	\N	\N	\N	\N	3
26	OM	9	OM-2022100009	BNPPI APHP VICTORIA	Parvis de l'hôtel de ville	75001	PARIS	30600.00	2022-10-14	\N	Tranche ferme APS/PC	ATT	\N	\N	\N	\N	3
27	OM	10	OM-2022100010	STAM EUROPE IRVE	Parcs existants			16400.00	2022-10-14	\N	Note générale + 7 parcs	ATT	\N	\N	\N	\N	3
\.


--
-- Data for Name: bdd_pilote; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.bdd_pilote (id, "Civilite", "Nom", "Prenom", "Tel_Portable", "Tel_Fixe", "Email") FROM stdin;
1	M.	GAUDY	Jean-Michel	0637859159		jmg@ingeprev.com
3	M.	SIMON	Frédéric	0638467631		fs@ingeprev.com
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2022-07-02 14:36:02.335982+00	1	Gerant	1	[{"added": {}}]	4	1
2	2022-07-02 14:36:29.29594+00	2	JMG	1	[{"added": {}}]	18	1
3	2022-07-02 14:36:49.058581+00	2	JMG	2	[{"changed": {"fields": ["First name", "Last name", "Staff status", "Groups"]}}]	18	1
4	2022-07-02 14:37:11.17284+00	3	FS	1	[{"added": {}}]	18	1
5	2022-07-02 14:37:27.946277+00	3	FS	2	[{"changed": {"fields": ["First name", "Last name", "Staff status", "Groups"]}}]	18	1
6	2022-07-02 14:38:04.3134+00	1	Ingeprev object (1)	1	[{"added": {}}]	17	3
7	2022-07-02 14:39:01.364714+00	1	Gerant	2	[{"changed": {"fields": ["Permissions"]}}]	4	1
8	2022-07-03 21:29:20.078419+00	1	Ingeprev object (1)	2	[{"changed": {"fields": ["N\\u00b0 de SIRET"]}}]	17	1
9	2022-07-04 18:46:18.728239+00	2	USWDS	2	[{"changed": {"fields": ["Logo"]}}]	1	1
10	2022-07-04 22:05:32.737598+00	2	USWDS	2	[{"changed": {"fields": ["Title"]}}]	1	1
11	2022-07-04 22:05:56.023271+00	2	USWDS	2	[{"changed": {"fields": ["Background color"]}}]	1	1
12	2022-07-04 22:06:30.476661+00	2	USWDS	2	[{"changed": {"fields": ["Background color"]}}]	1	1
13	2022-07-04 22:07:19.739875+00	2	USWDS	2	[]	1	1
14	2022-07-04 22:07:28.962194+00	1	Django	2	[]	1	1
15	2022-07-04 22:07:33.08746+00	1	Django	2	[{"changed": {"fields": ["Active"]}}]	1	1
16	2022-07-04 22:07:39.085913+00	2	USWDS	2	[{"changed": {"fields": ["Active"]}}]	1	1
17	2022-07-04 22:08:28.743049+00	1	Ingeprev object (1)	2	[{"changed": {"fields": ["Logo"]}}]	17	2
18	2022-07-06 11:46:49.655407+00	1	Ingeprev object (1)	2	[{"changed": {"fields": ["Statut juridique"]}}]	17	1
19	2022-07-10 11:06:18.687093+00	1	GAUDY Jean-Michel	1	[{"added": {}}]	13	1
20	2022-07-10 11:06:24.934627+00	1	Test Envoi mail , OM-2022070001 	1	[{"added": {}}]	14	1
21	2022-07-10 11:06:30.118699+00	1	Test Envoi mail , OM-2022070001 	2	[]	14	1
22	2022-07-10 11:07:24.049008+00	1	Tes 1 ,  	1	[{"added": {}}]	8	1
23	2022-07-10 11:07:43.937636+00	1	Tes 1 ,  	2	[{"changed": {"fields": ["Email"]}}]	8	1
24	2022-07-10 11:08:33.044934+00	1	JFG , Gaudy 	1	[{"added": {}}]	10	1
25	2022-07-10 11:08:47.432696+00	1	Test Envoi mail , A-2022070001 	2	[{"changed": {"fields": ["Payeur", "Adresse Envoi Facture"]}}]	7	1
28	2022-07-10 11:12:05.053877+00	1	Facture object (1)	2	[{"changed": {"fields": ["Descriptif"]}}]	15	1
30	2022-07-10 11:13:28.165531+00	1	Test 1 ,  	2	[{"changed": {"fields": ["D\\u00e9nomination sociale"]}}]	8	1
31	2022-07-10 11:13:33.728205+00	1	Facture object (1)	2	[{"changed": {"fields": ["Montant Facture H.T."]}}]	15	1
32	2022-07-10 11:13:55.198731+00	1	InfoEmail object (1)	2	[{"changed": {"fields": ["Message", "Pi\\u00e8ces jointes"]}}]	12	1
33	2022-07-10 11:15:18.876368+00	1	Facture object (1)	2	[]	15	1
34	2022-07-10 11:15:35.229266+00	2	Facture object (2)	2	[]	15	1
35	2022-07-10 11:15:59.647989+00	2	InfoEmail object (2)	2	[{"changed": {"fields": ["Message", "Pi\\u00e8ces jointes"]}}]	12	1
36	2022-07-10 11:16:19.388434+00	1	Test Envoi mail , A-2022070001 	2	[]	7	1
37	2022-07-10 11:16:34.237963+00	3	Facture object (3)	2	[{"changed": {"fields": ["Descriptif", "Montant Facture H.T."]}}]	15	1
38	2022-07-10 11:16:37.527592+00	3	InfoEmail object (3)	2	[{"changed": {"fields": ["Message", "Pi\\u00e8ces jointes"]}}]	12	1
39	2022-07-10 11:16:42.418797+00	3	Facture object (3)	2	[]	15	1
40	2022-07-10 11:16:54.140057+00	4	InfoEmail object (4)	2	[{"changed": {"fields": ["Message", "Pi\\u00e8ces jointes"]}}]	12	1
41	2022-07-10 11:17:00.997019+00	3	Facture object (3)	2	[]	15	1
43	2022-07-10 11:17:27.477829+00	3	Facture object (3)	2	[]	15	1
44	2022-07-10 11:17:56.408239+00	3	Facture object (3)	2	[]	15	1
45	2022-07-10 11:18:05.302698+00	8	InfoEmail object (8)	2	[{"changed": {"fields": ["RAR", "Pi\\u00e8ces jointes"]}}]	12	1
46	2022-07-10 11:18:26.529314+00	3	Facture object (3)	2	[]	15	1
47	2022-07-10 11:18:36.581194+00	9	InfoEmail object (9)	2	[{"changed": {"fields": ["RAR"]}}]	12	1
48	2022-07-10 11:18:56.381767+00	3	Facture object (3)	2	[]	15	1
49	2022-07-10 11:19:17.322086+00	3	Facture object (3)	2	[]	15	1
50	2022-07-10 11:26:59.001502+00	1	Test Envoi mail , OM-2022070001 	3		14	1
51	2022-07-10 11:33:07.785661+00	1	JFG , Gaudy 	3		10	1
52	2022-07-10 11:36:50.072708+00	2	 	1	[{"added": {}}]	13	2
53	2022-07-10 11:37:21.464629+00	2	 	3		13	2
54	2022-07-10 11:38:28.530968+00	1	GAUDY Jean-Michel	2	[{"changed": {"fields": ["Num\\u00e9ro de Portable"]}}]	13	2
55	2022-07-10 11:38:49.880749+00	1	GAUDY Jean-Michel	2	[{"changed": {"fields": ["Num\\u00e9ro de Portable"]}}]	13	2
56	2022-07-10 11:39:13.019698+00	1	GAUDY Jean-Michel	2	[{"changed": {"fields": ["Num\\u00e9ro de Portable"]}}]	13	2
57	2022-08-20 16:03:01.723512+00	1	Ingeprev object (1)	2	[{"changed": {"fields": ["Adresse", "Code postal", "Ville", "Code Banque", "Code Guichet", "Code BIC", "Num\\u00e9ro de Compte", "Cl\\u00e9", "Nom de la Banque", "Num\\u00e9ro de T\\u00e9l\\u00e9phone de la banque", "IBAN"]}}]	17	2
58	2022-08-29 08:12:39.944185+00	2	Comptable	1	[{"added": {}}]	4	1
59	2022-08-29 08:12:59.423087+00	4	COMPTABLE	1	[{"added": {}}]	18	1
60	2022-08-29 08:13:21.984684+00	4	COMPTABLE	2	[{"changed": {"fields": ["First name", "Last name", "Email address", "Staff status", "Groups"]}}]	18	1
61	2022-08-29 13:27:40.772823+00	4	COMPTABLE	3		18	1
62	2022-08-29 13:28:03.397417+00	5	COMPTABLE	1	[{"added": {}}]	18	1
63	2022-08-29 13:28:11.428126+00	5	COMPTABLE	2	[{"changed": {"fields": ["Staff status", "Groups"]}}]	18	1
64	2022-08-29 13:42:04.305663+00	5	COMPTABLE	2	[{"changed": {"fields": ["First name", "Last name", "Email address"]}}]	18	1
65	2022-08-29 17:11:52.367748+00	12	LogBackup object (12)	3		19	1
66	2022-08-29 17:11:52.42025+00	11	LogBackup object (11)	3		19	1
67	2022-08-29 17:11:52.432013+00	10	LogBackup object (10)	3		19	1
68	2022-08-29 17:11:52.447053+00	9	LogBackup object (9)	3		19	1
69	2022-08-29 17:11:52.458554+00	6	LogBackup object (6)	3		19	1
70	2022-08-29 17:11:52.470257+00	5	LogBackup object (5)	3		19	1
71	2022-08-29 17:11:52.482005+00	4	LogBackup object (4)	3		19	1
72	2022-08-29 17:11:52.495509+00	3	LogBackup object (3)	3		19	1
73	2022-08-29 17:11:52.513197+00	2	LogBackup object (2)	3		19	1
74	2022-08-29 17:11:52.524696+00	1	LogBackup object (1)	3		19	1
75	2022-08-30 07:03:26.092103+00	1	Gerant	2	[{"changed": {"fields": ["Permissions"]}}]	4	1
76	2022-09-07 14:17:14.823558+00	1	Ingeprev object (1)	2	[{"changed": {"fields": ["Num\\u00e9ro de Compte"]}}]	17	1
77	2022-09-07 14:17:37.72701+00	1	Ingeprev object (1)	2	[{"changed": {"fields": ["N\\u00b0 de SIRET"]}}]	17	1
78	2022-09-07 14:18:20.165668+00	1	Ingeprev object (1)	2	[]	17	1
79	2022-09-07 14:20:01.553111+00	21	LogBackup object (21)	3		19	1
80	2022-09-07 14:20:01.618195+00	20	LogBackup object (20)	3		19	1
81	2022-09-07 14:20:01.63668+00	19	LogBackup object (19)	3		19	1
82	2022-09-07 14:20:01.648176+00	18	LogBackup object (18)	3		19	1
83	2022-09-07 14:20:01.659855+00	17	LogBackup object (17)	3		19	1
84	2022-09-07 14:20:01.676992+00	16	LogBackup object (16)	3		19	1
85	2022-09-07 14:20:01.688544+00	15	LogBackup object (15)	3		19	1
86	2022-09-07 14:20:01.704843+00	14	LogBackup object (14)	3		19	1
87	2022-09-07 14:20:01.716145+00	13	LogBackup object (13)	3		19	1
88	2022-09-07 14:26:34.022053+00	1	Ingeprev object (1)	2	[{"changed": {"fields": ["Site Web"]}}]	17	1
89	2022-09-07 14:41:48.011515+00	1	Ingeprev object (1)	2	[{"changed": {"fields": ["Code Banque (saisir sans espaces)", "Code Guichet (saisir sans espaces)", "Code BIC", "Num\\u00e9ro de Compte (saisir sans espaces)", "Cl\\u00e9", "Num\\u00e9ro de T\\u00e9l\\u00e9phone de la banque", "IBAN (saisir sans espaces)"]}}]	17	1
90	2022-09-07 15:10:34.098178+00	2	SOGELYM DIXENCE , 488 091 968 RCS LYON 	1	[{"added": {}}]	8	2
91	2022-09-07 15:13:22.117887+00	2	SOGELYM DIXENCE , 488 091 968 RCS LYON 	2	[{"changed": {"fields": ["Civilite", "Nom", "Pr\\u00e9nom", "Email"]}}]	8	2
92	2022-09-07 15:14:49.953563+00	2	AMO Accessibilité Campus de Sciences Po , OM-2022090001 	1	[{"added": {}}]	14	2
93	2022-09-07 19:01:52.492873+00	1	Ingeprev object (1)	2	[{"changed": {"fields": ["Code Banque (saisir sans espaces)", "Code Guichet (saisir sans espaces)", "Code BIC", "Num\\u00e9ro de Compte (saisir sans espaces)", "Cl\\u00e9", "Num\\u00e9ro de T\\u00e9l\\u00e9phone de la banque", "IBAN (saisir sans espaces)"]}}]	17	1
94	2022-09-07 19:02:53.218412+00	1	Ingeprev object (1)	2	[]	17	1
95	2022-09-07 19:04:37.138664+00	1	Ingeprev object (1)	2	[{"changed": {"fields": ["Email"]}}]	17	1
96	2022-09-08 15:05:46.241089+00	3	HOLDING FINANCIERE JL ,  	1	[{"added": {}}]	8	2
97	2022-09-08 15:06:34.974542+00	3	HOLDING FINANCIERE JL ,  	2	[]	8	2
98	2022-09-08 15:11:35.320422+00	1	ASSEMBLY , ROUER 	1	[{"added": {}}]	11	2
99	2022-09-08 15:12:08.969931+00	4	ASSEMBLY ,  	1	[{"added": {}}]	8	2
100	2022-09-08 15:13:18.336762+00	3	Assembly - 27 Sampaix , OM-2022090002 	1	[{"added": {}}]	14	2
101	2022-09-08 16:26:06.696036+00	5	BNP PARIBAS REAL ESTATE ,  	1	[{"added": {}}]	8	2
102	2022-09-08 16:28:29.164557+00	2	ORFEO Développement ,  	1	[{"added": {}}]	11	2
103	2022-09-08 16:28:42.641459+00	2	ORFEO Développement ,  	2	[{"changed": {"fields": ["Code postal"]}}]	11	2
104	2022-09-08 16:29:19.957287+00	6	ORFEO Développement ,  	1	[{"added": {}}]	8	2
105	2022-09-08 16:30:06.969818+00	4	Orfeo - Austerlitz - Faisa Preneur , OM-2022090003 	1	[{"added": {}}]	14	2
106	2022-09-08 17:19:47.883924+00	7	SCI PREIM ONE MONCEAU ,  	1	[{"added": {}}]	8	2
107	2022-09-08 17:23:30.442703+00	5	Orfeo - One Monceau , OM-2022090004 	1	[{"added": {}}]	14	2
108	2022-09-09 07:34:20.218916+00	3	SIMON Frédéric	1	[{"added": {}}]	13	3
109	2022-09-09 13:56:57.215495+00	6	Redéveloppement du 32 av Kleber à Colombes - Hôtel logistique , OM-2022090005 	1	[{"added": {}}]	14	3
110	2022-09-10 06:43:19.969955+00	3	FS	2	[{"changed": {"fields": ["Email address"]}}]	18	1
111	2022-09-10 06:45:32.57836+00	3	Assembly - 27 Sampaix , OM-2022090002 	2	[{"changed": {"fields": ["Descriptif"]}}]	14	1
112	2022-09-10 16:11:53.709949+00	8	SCI 69 CHARONNE Représentée par Batipart Immo Euro ,  	1	[{"added": {}}]	8	2
113	2022-09-10 16:12:52.872743+00	8	SCI 69 CHARONNE Représentée par Batipart Immo Euro ,  	2	[{"changed": {"fields": ["Adresse", "Code postal", "Ville"]}}]	8	2
114	2022-09-10 16:15:08.074148+00	7	Orfeo - Murmure , OM-2022090006 	1	[{"added": {}}]	14	2
115	2022-09-10 16:18:13.217728+00	7	Orfeo - Murmure , OM-2022090006 	2	[{"changed": {"fields": ["Descriptif"]}}]	14	2
116	2022-09-10 16:27:18.660791+00	8	SCI 69 CHARONNE Représentée par Batipart Immo Euro ,  	2	[]	8	2
117	2022-09-10 16:27:18.778009+00	8	SCI 69 CHARONNE Représentée par Batipart Immo Euro ,  	2	[]	8	2
118	2022-09-10 16:30:24.993207+00	8	SCI 69 CHARONNE Représentée par Batipart Immo Euro ,  	2	[]	8	1
119	2022-09-10 16:32:17.91677+00	8	SCI 69 CHARONNE Représentée par Batipart Immo Europe Management France ,  	2	[{"changed": {"fields": ["D\\u00e9nomination sociale"]}}]	8	2
120	2022-09-10 17:12:47.713995+00	8	Orfeo - Faisabilité Tour Blanche , OM-2022090007 	1	[{"added": {}}]	14	2
121	2022-09-10 19:20:01.646771+00	9	TS CRISTAL SCI ,  	1	[{"added": {}}]	8	2
122	2022-09-10 19:21:34.162062+00	10	TISHMAN SPEYER ,  	1	[{"added": {}}]	8	2
123	2022-09-10 19:22:32.703679+00	9	Tour Cristal / Diamond , OM-2022090008 	1	[{"added": {}}]	14	2
124	2022-09-10 23:12:01.507061+00	11	AG 38 Blancs Manteaux ,  	1	[{"added": {}}]	8	2
125	2022-09-10 23:14:54.401886+00	10	Orfeo - Blancs Manteaux , OM-2022090009 	1	[{"added": {}}]	14	2
126	2022-09-11 13:38:30.733864+00	12	VILLAGE 7 DEFENSE ,  	1	[{"added": {}}]	8	2
127	2022-09-11 13:39:53.813341+00	13	URW ,  	1	[{"added": {}}]	8	2
128	2022-09-11 13:41:29.266712+00	11	URW - Village 7 , OM-2022090010 	1	[{"added": {}}]	14	2
129	2022-09-11 14:37:03.25691+00	14	SAS BERCY LUMIERE S/C SEFAL PROPERTY ,  	1	[{"added": {}}]	8	2
130	2022-09-11 14:39:10.641616+00	12	Lumière - RIE "La Source" , OM-2022090011 	1	[{"added": {}}]	14	2
131	2022-09-11 16:06:12.288743+00	15	SAS BERCY LUMIERE S/C MAYA Advisors ,  	1	[{"added": {}}]	8	2
132	2022-09-11 16:06:39.553249+00	13	Lumière - Atrium , OM-2022090012 	1	[{"added": {}}]	14	2
133	2022-09-11 21:10:41.581827+00	16	Ministère de la Justice ,  	1	[{"added": {}}]	8	2
134	2022-09-11 21:11:24.486036+00	17	2BDM ,  	1	[{"added": {}}]	8	2
135	2022-09-11 21:12:28.855775+00	14	PdJ - B5 Culture , OM-2022090013 	1	[{"added": {}}]	14	2
136	2022-09-13 13:27:07.373653+00	5	Orfeo - One Monceau , OM-2022090004 	2	[{"changed": {"fields": ["Honoraires H.T.", "Descriptif"]}}]	14	2
137	2022-09-13 13:28:58.141834+00	2	Orfeo - One Monceau , A-2022090001 	1	[{"added": {}}]	7	2
138	2022-09-13 13:31:07.765627+00	2	Orfeo - One Monceau , A-2022090001 	2	[{"changed": {"fields": ["Date pr\\u00e9visionnelle de facturation"]}}]	7	2
139	2022-09-13 13:32:54.829501+00	2	Orfeo - One Monceau , A-2022090001 	2	[]	7	2
140	2022-09-16 07:50:17.287921+00	3	TISHMAN SPEYER , BREVET 	1	[{"added": {}}]	11	3
141	2022-09-16 07:51:57.841146+00	15	NOVA VILLEJUIF - TISHMAN SPEYER , OM-2022090014 	1	[{"added": {}}]	14	3
142	2022-09-16 07:56:33.354084+00	6	Hôtel Logistique à Colombes - THEOP , OM-2022090005 	2	[{"changed": {"fields": ["Nom de la mission"]}}]	14	3
143	2022-09-26 14:59:38.332642+00	18	Général Pop ,  	1	[{"added": {}}]	8	2
144	2022-09-26 15:00:11.262493+00	19	BETC ,  	1	[{"added": {}}]	8	2
145	2022-09-26 15:00:59.101483+00	16	BETC - Studio BroadCast , OM-2022090015 	1	[{"added": {}}]	14	2
146	2022-09-26 15:10:29.463371+00	16	BETC - Studio BroadCast , OM-2022090015 	2	[{"changed": {"fields": ["Honoraires H.T."]}}]	14	2
147	2022-09-26 17:55:33.922504+00	20	CHROME ,  	1	[{"added": {}}]	8	2
148	2022-09-26 17:56:43.553701+00	21	F8 Architecteure ,  	1	[{"added": {}}]	8	2
149	2022-09-26 17:58:05.210822+00	17	Hekla - Aménagements F8 / Chrome , OM-2022090016 	1	[{"added": {}}]	14	2
150	2022-10-02 16:14:29.044716+00	22	Ministère de l’Intérieur DEPAFI / SDAI / BGSAC ,  	1	[{"added": {}}]	8	2
151	2022-10-02 16:15:36.505154+00	18	Lumière - MINT R+2 Enclave Garonne , OM-2022100001 	1	[{"added": {}}]	14	2
152	2022-10-03 12:40:12.772553+00	10	Orfeo - Blancs Manteaux , OM-2022090009 	2	[]	14	2
153	2022-10-03 12:41:28.025516+00	11	38 rue des Blancs Manteaux SCI ,  	2	[{"changed": {"fields": ["D\\u00e9nomination sociale", "Adresse", "Code postal", "Ville", "Civilite", "Nom", "Pr\\u00e9nom"]}}]	8	2
154	2022-10-03 12:50:09.679719+00	3	ORFEO Développement , MULLIE 	2	[{"changed": {"fields": ["D\\u00e9nomination sociale", "Adresse", "Code postal", "Ville", "Civilite", "Nom", "Pr\\u00e9nom", "Email", "D\\u00e9lais de Paiement (en jours)", "Fin de Mois", "Modalit\\u00e9s particuli\\u00e8res de Paiement"]}}]	10	2
155	2022-10-03 12:51:39.735169+00	3	Orfeo - Blancs Manteaux , A-2022100001 	2	[{"changed": {"fields": ["R\\u00e9f\\u00e9rence Client \\u00e0 rappeler", "Date pr\\u00e9visionnelle de facturation"]}}]	7	2
156	2022-10-03 13:05:11.174755+00	23	Chartier Dalix ,  	1	[{"added": {}}]	8	3
157	2022-10-03 13:07:51.091921+00	19	L'OREAL CLICHY CES A , OM-2022100002 	1	[{"added": {}}]	14	3
158	2022-10-03 13:10:32.352524+00	15	NOVA VILLEJUIF - TISHMAN SPEYER , OM-2022090014 	2	[{"changed": {"fields": ["Honoraires H.T.", "Date de Proposition"]}}]	14	3
159	2022-10-05 12:26:15.337865+00	14	PdJ - B5 Culture , OM-2022090013 	2	[{"changed": {"fields": ["Descriptif"]}}]	14	2
160	2022-10-05 12:28:58.329444+00	3	ORFEO Développement , MULLIE 	2	[]	10	2
161	2022-10-05 12:29:51.492629+00	3	ORFEO Développement , MULLIE 	2	[{"changed": {"fields": ["Modalit\\u00e9s particuli\\u00e8res de Paiement"]}}]	10	2
162	2022-10-05 12:30:31.909306+00	3	Orfeo - Blancs Manteaux , A-2022100001 	2	[]	7	2
163	2022-10-05 12:30:49.076926+00	4	Facture object (4)	2	[{"changed": {"fields": ["Descriptif"]}}]	15	2
164	2022-10-05 12:31:43.600052+00	4	Facture object (4)	3		15	2
165	2022-10-05 13:27:54.161627+00	6	ORFEO Développement ,  	2	[]	8	2
166	2022-10-05 13:28:55.896472+00	20	ORFEO - Inspire Puteaux - Due Diligence , OM-2022100003 	1	[{"added": {}}]	14	2
167	2022-10-05 13:30:40.03732+00	13	Lumière - Atrium , OM-2022090012 	2	[{"changed": {"fields": ["Pilote"]}}]	14	2
168	2022-10-07 07:15:10.136129+00	24	EGIS ,  	1	[{"added": {}}]	8	3
169	2022-10-07 07:17:32.412191+00	25	CSD & ASSOCIES ,  	1	[{"added": {}}]	8	3
170	2022-10-07 07:18:00.249977+00	21	EGIS - Projet MARIGNAN MONTREUIL , OM-2022100004 	1	[{"added": {}}]	14	3
171	2022-10-08 10:37:03.375644+00	4	2BDM ,  	1	[{"added": {}}]	11	2
172	2022-10-08 10:37:56.402354+00	22	PdJ - B5 Justice , OM-2022100005 	1	[{"added": {}}]	14	2
173	2022-10-08 13:38:02.454696+00	3	Assembly - 27 Sampaix , OM-2022090002 	2	[]	14	2
174	2022-10-08 13:48:23.872009+00	3	SNC DU 27 RUE LUCIEN SAMPAIX ,  	2	[{"changed": {"fields": ["D\\u00e9nomination sociale", "Adresse", "Code postal", "Ville"]}}]	8	2
175	2022-10-08 13:54:26.372742+00	4	ASSEMBLY ,  	2	[{"changed": {"fields": ["D\\u00e9nomination sociale", "Adresse", "D\\u00e9lais de Paiement (en jours)", "Fin de Mois", "Modalit\\u00e9s particuli\\u00e8res de Paiement"]}}]	10	2
176	2022-10-08 13:54:43.189366+00	4	Assembly - 27 Sampaix , A-2022100002 	2	[{"changed": {"fields": ["Date pr\\u00e9visionnelle de facturation"]}}]	7	2
177	2022-10-08 14:56:12.679971+00	16	BETC - Studio BroadCast , OM-2022090015 	2	[{"changed": {"fields": ["Honoraires H.T."]}}]	14	2
178	2022-10-08 16:01:08.57876+00	23	Orfeo - Rives de Seine - GH 65 , OM-2022100006 	1	[{"added": {}}]	14	2
179	2022-10-10 17:29:47.05281+00	16	BETC - Studio BroadCast , OM-2022090015 	2	[]	14	2
180	2022-10-10 17:31:18.168459+00	5	Général Pop ,  	2	[{"changed": {"fields": ["D\\u00e9lais de Paiement (en jours)", "Fin de Mois", "Modalit\\u00e9s particuli\\u00e8res de Paiement"]}}]	10	2
181	2022-10-10 17:31:28.046767+00	5	BETC - Studio BroadCast , A-2022100003 	2	[]	7	2
182	2022-10-10 17:32:04.39148+00	5	BETC - Studio BroadCast , A-2022100003 	2	[{"changed": {"fields": ["Date pr\\u00e9visionnelle de facturation"]}}]	7	2
183	2022-10-11 18:47:47.204809+00	26	SCI 74 Champs-Elysées ,  	1	[{"added": {}}]	8	3
184	2022-10-11 18:51:06.854032+00	24	AXA - 74 avenue des Champs-Elysées , OM-2022100007 	1	[{"added": {}}]	14	3
185	2022-10-13 19:05:37.198211+00	27	BNPPI ,  	1	[{"added": {}}]	8	3
186	2022-10-13 19:11:31.245594+00	25	CACHAN PLURIELS , OM-2022100008 	1	[{"added": {}}]	14	3
187	2022-10-14 15:06:01.417081+00	26	BNPPI APHP VICTORIA , OM-2022100009 	1	[{"added": {}}]	14	3
188	2022-10-14 16:50:06.461385+00	28	STAM EUROPE ,  	1	[{"added": {}}]	8	3
189	2022-10-14 16:52:14.63782+00	27	STAM EUROPE IRVE , OM-2022100010 	1	[{"added": {}}]	14	3
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin_interface	theme
2	admin	logentry
3	auth	permission
4	auth	group
5	contenttypes	contenttype
6	sessions	session
7	bdd	affaire
8	bdd	client
9	bdd	compteur_indice
10	bdd	envoi_facture
11	bdd	envoi_offre
12	bdd	infoemail
13	bdd	pilote
14	bdd	offre_mission
15	bdd	facture
16	bdd	attachment
17	bdd	ingeprev
18	authentification	user
19	processes	logbackup
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2022-07-02 14:28:56.532103+00
2	contenttypes	0002_remove_content_type_name	2022-07-02 14:28:56.545335+00
3	auth	0001_initial	2022-07-02 14:28:56.78115+00
4	auth	0002_alter_permission_name_max_length	2022-07-02 14:28:56.808505+00
5	auth	0003_alter_user_email_max_length	2022-07-02 14:28:56.826063+00
6	auth	0004_alter_user_username_opts	2022-07-02 14:28:56.853273+00
7	auth	0005_alter_user_last_login_null	2022-07-02 14:28:56.873801+00
8	auth	0006_require_contenttypes_0002	2022-07-02 14:28:56.889507+00
9	auth	0007_alter_validators_add_error_messages	2022-07-02 14:28:56.912133+00
10	auth	0008_alter_user_username_max_length	2022-07-02 14:28:56.932404+00
11	auth	0009_alter_user_last_name_max_length	2022-07-02 14:28:56.95245+00
12	auth	0010_alter_group_name_max_length	2022-07-02 14:28:56.980163+00
13	auth	0011_update_proxy_permissions	2022-07-02 14:28:57.000463+00
14	auth	0012_alter_user_first_name_max_length	2022-07-02 14:28:57.02117+00
15	authentification	0001_initial	2022-07-02 14:28:57.293361+00
16	admin	0001_initial	2022-07-02 14:28:57.433916+00
17	admin	0002_logentry_remove_auto_add	2022-07-02 14:28:57.462669+00
18	admin	0003_logentry_add_action_flag_choices	2022-07-02 14:28:57.478608+00
19	admin_interface	0001_initial	2022-07-02 14:28:57.537391+00
20	admin_interface	0002_add_related_modal	2022-07-02 14:28:57.573145+00
21	admin_interface	0003_add_logo_color	2022-07-02 14:28:57.593589+00
22	admin_interface	0004_rename_title_color	2022-07-02 14:28:57.617178+00
23	admin_interface	0005_add_recent_actions_visible	2022-07-02 14:28:57.629537+00
24	admin_interface	0006_bytes_to_str	2022-07-02 14:28:57.711192+00
25	admin_interface	0007_add_favicon	2022-07-02 14:28:57.730176+00
26	admin_interface	0008_change_related_modal_background_opacity_type	2022-07-02 14:28:57.753859+00
27	admin_interface	0009_add_enviroment	2022-07-02 14:28:57.779074+00
28	admin_interface	0010_add_localization	2022-07-02 14:28:57.820192+00
29	admin_interface	0011_add_environment_options	2022-07-02 14:28:57.845324+00
30	admin_interface	0012_update_verbose_names	2022-07-02 14:28:57.872749+00
31	admin_interface	0013_add_related_modal_close_button	2022-07-02 14:28:57.892456+00
32	admin_interface	0014_name_unique	2022-07-02 14:28:57.984513+00
33	admin_interface	0015_add_language_chooser_active	2022-07-02 14:28:58.004336+00
34	admin_interface	0016_add_language_chooser_display	2022-07-02 14:28:58.030241+00
35	admin_interface	0017_change_list_filter_dropdown	2022-07-02 14:28:58.050207+00
36	admin_interface	0018_theme_list_filter_sticky	2022-07-02 14:28:58.07385+00
37	admin_interface	0019_add_form_sticky	2022-07-02 14:28:58.102478+00
38	admin_interface	0020_module_selected_colors	2022-07-02 14:28:58.143136+00
39	admin_interface	0021_file_extension_validator	2022-07-02 14:28:58.170582+00
40	admin_interface	0022_add_logo_max_width_and_height	2022-07-02 14:28:58.196279+00
41	admin_interface	0023_theme_foldable_apps	2022-07-02 14:28:58.217441+00
42	admin_interface	0024_remove_theme_css	2022-07-02 14:28:58.233213+00
43	bdd	0001_initial	2022-07-02 14:28:59.205057+00
44	bdd	0002_ingeprev_delete_entreprise_alter_affaire_options_and_more	2022-07-02 14:28:59.371609+00
45	bdd	0003_ingeprev_cle_ingeprev_code_bic_ingeprev_code_banque_and_more	2022-07-02 14:28:59.456533+00
46	bdd	0004_facture_date_previsionnelle	2022-07-02 14:28:59.47773+00
47	bdd	0005_remove_facture_date_previsionnelle	2022-07-02 14:28:59.544006+00
48	bdd	0006_facture_date_relance6	2022-07-02 14:28:59.56756+00
49	bdd	0007_ingeprev_logo	2022-07-02 14:28:59.583303+00
50	bdd	0008_alter_ingeprev_logo	2022-07-02 14:28:59.60529+00
51	bdd	0009_facture_avoir_lie_alter_affaire_type_affaire_and_more	2022-07-02 14:28:59.716609+00
52	bdd	0010_facture_facture_liee	2022-07-02 14:28:59.742061+00
53	bdd	0011_remove_facture_avoir_lie_alter_facture_facture_liee_and_more	2022-07-02 14:28:59.785208+00
54	sessions	0001_initial	2022-07-02 14:28:59.906778+00
55	bdd	0012_facture_num_suivi_infoemail_suivi_and_more	2022-08-22 16:03:53.645582+00
56	bdd	0013_alter_facture_date_relance1_and_more	2022-08-22 16:03:53.727319+00
57	processes	0001_initial	2022-08-29 15:01:20.884186+00
58	processes	0002_logbackup_size	2022-08-29 15:03:59.992429+00
59	processes	0003_alter_logbackup_fichier	2022-08-29 16:32:28.726023+00
60	bdd	0014_affaire_ref_client	2022-09-07 14:14:14.76294+00
61	bdd	0015_facture_ref_client	2022-09-07 14:14:14.833501+00
62	bdd	0016_alter_envoi_facture_delais_paiement_and_more	2022-09-07 14:14:14.969283+00
63	bdd	0017_alter_ingeprev_code_banque_and_more	2022-09-07 14:14:15.138504+00
64	bdd	0018_alter_ingeprev_num_compte	2022-09-07 14:14:15.151872+00
65	bdd	0019_alter_ingeprev_code_banque_and_more	2022-09-07 14:34:29.320619+00
66	bdd	0020_alter_ingeprev_siret	2022-09-10 16:24:37.166158+00
67	bdd	0021_alter_client_denomination_sociale_and_more	2022-09-10 16:30:12.099855+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
1ym88td9w7gcab570g1ceynv0287sb2o	.eJxVjEEOwiAQRe_C2pBhqMi4dO8ZCAyMVE1JSrsy3l2bdKHb_977LxXiutSw9jKHMauzMurwu6XIjzJtIN_jdGua27TMY9Kbonfa9bXl8rzs7t9Bjb1-a2THIDjYcmRPGWhIQmSJEBJmcUkkgYtsxHtB8uCFyQ4RGA2fENT7A-foN9w:1oieF6:zY2cH3WNE0YGlf09pcRHFYG8Qky4vLX6SHaXAY6O-vI	2022-10-26 16:06:00.266365+00
f1xmp524cdz648647gc9try5ccakny42	.eJxVjEEOwiAQRe_C2pBhqMi4dO8ZCAyMVE1JSrsy3l2bdKHb_977LxXiutSw9jKHMauzMurwu6XIjzJtIN_jdGua27TMY9Kbonfa9bXl8rzs7t9Bjb1-a2THIDjYcmRPGWhIQmSJEBJmcUkkgYtsxHtB8uCFyQ4RGA2fENT7A-foN9w:1o7eGM:1k0NHr_7TyCw25YEDTlhuOGO1RlBAoMQcjOncTiYtnQ	2022-07-16 14:38:22.616727+00
c0iggoy54hyluzer3od53pl8hwf2s8et	.eJxVjEEOwiAQRe_C2pBhqMi4dO8ZCAyMVE1JSrsy3l2bdKHb_977LxXiutSw9jKHMauzMurwu6XIjzJtIN_jdGua27TMY9Kbonfa9bXl8rzs7t9Bjb1-a2THIDjYcmRPGWhIQmSJEBJmcUkkgYtsxHtB8uCFyQ4RGA2fENT7A-foN9w:1o83Id:vRMOBVEiuFPc9wbdB1hMcN4GV_mLHuoWibjnAAiw-OM	2022-07-17 17:22:23.973386+00
yhu1ahg0rfjw0dxafvdrix6dvu9bikd9	.eJxVjDsOwjAQBe_iGlnxb2VT0nMGy-vd4ACypTipIu5OIqWAdmbe20RM61Li2nmOE4mrMOLyyzDlF9dD0DPVR5O51WWeUB6JPG2X90b8vp3t30FJvexrj8gEHhU4UA4BtFZ-GJ3TmayHbJLLlsyODOAQFAKPFgBUwMAWtfh8AdCmN0o:1oWYOI:9tyItXWLUaO6PKBjQu-gnB1TzDBuKSLUb_L6xFAscFc	2022-09-23 07:25:30.858819+00
ju361gsfzbtx6zk0g30817ehx1xumft5	.eJxVjEEOwiAQRe_C2pBhqMi4dO8ZCAyMVE1JSrsy3l2bdKHb_977LxXiutSw9jKHMauzMurwu6XIjzJtIN_jdGua27TMY9Kbonfa9bXl8rzs7t9Bjb1-a2THIDjYcmRPGWhIQmSJEBJmcUkkgYtsxHtB8uCFyQ4RGA2fENT7A-foN9w:1oWeTE:kgQzFHoBnBfu4SrFIY8Dl8CVRSFst_GFNzmS1k0BvV8	2022-09-23 13:55:00.233814+00
848bzv7ax20euq4y999zyggiqb93t2c3	.eJxVjEEOwiAQRe_C2pBhqMi4dO8ZCAyMVE1JSrsy3l2bdKHb_977LxXiutSw9jKHMauzMurwu6XIjzJtIN_jdGua27TMY9Kbonfa9bXl8rzs7t9Bjb1-a2THIDjYcmRPGWhIQmSJEBJmcUkkgYtsxHtB8uCFyQ4RGA2fENT7A-foN9w:1oHnu6:wiBBWW9q0WaNs-lbzawm6_v9YjWCgw7dw7oVTfBZi78	2022-08-13 14:57:22.811547+00
c4ma4bffg05gm8g3vdqzebo0yuoa8yhx	.eJxVjEEOwiAQRe_C2hAYMmBduvcMZGAGqRqalHbVeHdt0oVu_3vvbyrSutS4dpnjyOqiUJ1-t0T5KW0H_KB2n3Se2jKPSe-KPmjXt4nldT3cv4NKvX5rlx04z1DQs88DWUIhm4AKn70AhpKBsFjrkQNLgGDyAAFMQmvEBfX-AO_1N8c:1oY6ji:dAo3hto5HMotk9AFv7OObcpMIcZEQcAbGe1oFbr9nw0	2022-09-27 14:18:02.444441+00
vzf3oaxoicfpqa44iz8jhn4mh6j3578l	.eJxVjEEOwiAQRe_C2pBhqMi4dO8ZCAyMVE1JSrsy3l2bdKHb_977LxXiutSw9jKHMauzMurwu6XIjzJtIN_jdGua27TMY9Kbonfa9bXl8rzs7t9Bjb1-a2THIDjYcmRPGWhIQmSJEBJmcUkkgYtsxHtB8uCFyQ4RGA2fENT7A-foN9w:1oQAX0:ut8icPXJAJAlM5T6NEG35AmaecgbKQ58JSZItJB9R5Q	2022-09-05 16:44:06.008085+00
7t84xka10n3rzlzl0ytisri28vcewqn0	.eJxVjDsOwjAQBe_iGln-sjYlfc5grb0bHECOFCcV4u4QKQW0b2beSyTc1pq2zkuaSFyEEaffLWN5cNsB3bHdZlnmti5TlrsiD9rlMBM_r4f7d1Cx128dNLtR6Vis5kLAhkpEisH5sYBizIaC9TobANCZtbLeZTaOCKKFM4j3B_J3N9k:1ocpWq:uSkuLrZJvwra_hLiL0-V08btUtuEUeOBwiq_LLYXbHM	2022-10-10 14:56:16.6493+00
qwp0f8x6vg1a84xu52dne67t7tdg1dza	.eJxVjMEOwiAQRP-FsyGFBbZ69N5vIAsLUjU0Ke3J-O9K0oNmbvPezEt42rfi95ZWP7O4CCdOv12g-Ei1A75TvS0yLnVb5yC7Ig_a5LRwel4P9--gUCt9bYkiJcA4aqutsRFcTgMDGgDMmTOfDQ6BNY9gyWAICr9RRikEF8X7A_SSN50:1oShoV:qgcp6Kt6h708R2cK5kftn-BNcZBnEp4BKMyVQuuRFuU	2022-09-12 16:40:39.634289+00
zaucj82ttngokbpwkkeojaba542e0jhg	.eJxVjMEOwiAQRP-FsyGFBbZ69N5vIAsLUjU0Ke3J-O9K0oNmbvPezEt42rfi95ZWP7O4CCdOv12g-Ei1A75TvS0yLnVb5yC7Ig_a5LRwel4P9--gUCt9bYkiJcA4aqutsRFcTgMDGgDMmTOfDQ6BNY9gyWAICr9RRikEF8X7A_SSN50:1oShxA:0183fH8i5lBwfLVGPO-Jz363Qz4R0v034ZvsijMcF3E	2022-09-12 16:49:36.837517+00
eaavhowjpsb8f8cn8chb8yweryjzxt3o	.eJxVjEEOwiAQRe_C2hAYMmBduvcMZGAGqRqalHbVeHdt0oVu_3vvbyrSutS4dpnjyOqiUJ1-t0T5KW0H_KB2n3Se2jKPSe-KPmjXt4nldT3cv4NKvX5rlx04z1DQs88DWUIhm4AKn70AhpKBsFjrkQNLgGDyAAFMQmvEBfX-AO_1N8c:1oeIFS:BACiP7omvNoBNI3EqgJnfEgosKWRg1fTqQ9ATxuoRmc	2022-10-14 15:48:22.038737+00
tw7njndmlo382xcf68omesz57pgfqkws	.eJxVjDsOwjAQBe_iGlnxb2VT0nMGy-vd4ACypTipIu5OIqWAdmbe20RM61Li2nmOE4mrMOLyyzDlF9dD0DPVR5O51WWeUB6JPG2X90b8vp3t30FJvexrj8gEHhU4UA4BtFZ-GJ3TmayHbJLLlsyODOAQFAKPFgBUwMAWtfh8AdCmN0o:1ofL5x:q5XPzrlpRMnbQkfhvWR7l2jWW_8EEJFG9WBjaJJCrzQ	2022-10-17 13:02:53.861753+00
txiql12lwvehcpv9rywq7oe4lpehu7df	.eJxVjEEOwiAQRe_C2pBhqMi4dO8ZCAyMVE1JSrsy3l2bdKHb_977LxXiutSw9jKHMauzMurwu6XIjzJtIN_jdGua27TMY9Kbonfa9bXl8rzs7t9Bjb1-a2THIDjYcmRPGWhIQmSJEBJmcUkkgYtsxHtB8uCFyQ4RGA2fENT7A-foN9w:1ofQDB:fmHao_RbYL_KgdHfy5s_PuChqNaHBdXApDZwgvRoZ50	2022-10-17 18:30:41.209324+00
ofqw8jho8dt4mhp97ikf24avxplee4rh	.eJxVjMEOwiAQRP-FsyGFBbZ69N5vIAsLUjU0Ke3J-O9K0oNmbvPezEt42rfi95ZWP7O4CCdOv12g-Ei1A75TvS0yLnVb5yC7Ig_a5LRwel4P9--gUCt9bYkiJcA4aqutsRFcTgMDGgDMmTOfDQ6BNY9gyWAICr9RRikEF8X7A_SSN50:1ohowk:k1IT-xWFw8QEXYS3dCNr60JUFRp3Whz78zWTbipk4-U	2022-10-24 09:19:38.030363+00
72b8hj7ry3b6xdzhmg5bhcfvmkvbm5ab	.eJxVjDsOwjAQBe_iGln-sjYlfc5grb0bHECOFCcV4u4QKQW0b2beSyTc1pq2zkuaSFyEEaffLWN5cNsB3bHdZlnmti5TlrsiD9rlMBM_r4f7d1Cx128dNLtR6Vis5kLAhkpEisH5sYBizIaC9TobANCZtbLeZTaOCKKFM4j3B_J3N9k:1ohwWo:3tmK438jQFNNQGrX_ocUmwzpYZw77I0v97Jji2kKhxs	2022-10-24 17:25:22.558673+00
\.


--
-- Data for Name: processes_logbackup; Type: TABLE DATA; Schema: public; Owner: claire
--

COPY public.processes_logbackup (id, dt, dt_end, success, fichier, size) FROM stdin;
34	2022-09-19 00:00:02.639193+00	2022-09-19 00:00:02.886815+00	t	/home/claire/Backup/bdd/20220919-000002-bdd.sql.gz	19156
35	2022-09-20 00:00:02.017735+00	2022-09-20 00:00:02.255744+00	t	/home/claire/Backup/bdd/20220920-000002-bdd.sql.gz	19182
36	2022-09-21 00:00:02.304318+00	2022-09-21 00:00:02.556129+00	t	/home/claire/Backup/bdd/20220921-000002-bdd.sql.gz	19206
37	2022-09-22 00:00:01.766712+00	2022-09-22 00:00:01.993159+00	t	/home/claire/Backup/bdd/20220922-000001-bdd.sql.gz	19226
38	2022-09-23 00:00:02.665583+00	2022-09-23 00:00:02.916103+00	t	/home/claire/Backup/bdd/20220923-000002-bdd.sql.gz	19249
39	2022-09-24 00:00:01.953867+00	2022-09-24 00:00:02.182191+00	t	/home/claire/Backup/bdd/20220924-000001-bdd.sql.gz	19274
40	2022-09-25 00:00:02.365235+00	2022-09-25 00:00:02.597067+00	t	/home/claire/Backup/bdd/20220925-000002-bdd.sql.gz	19305
41	2022-09-26 00:00:01.741709+00	2022-09-26 00:00:01.97671+00	t	/home/claire/Backup/bdd/20220926-000001-bdd.sql.gz	19329
42	2022-09-27 00:00:02.099339+00	2022-09-27 00:00:02.337973+00	t	/home/claire/Backup/bdd/20220927-000002-bdd.sql.gz	19899
43	2022-09-28 00:00:02.625816+00	2022-09-28 00:00:02.865128+00	t	/home/claire/Backup/bdd/20220928-000002-bdd.sql.gz	19920
44	2022-09-29 00:00:01.912909+00	2022-09-29 00:00:02.143529+00	t	/home/claire/Backup/bdd/20220929-000001-bdd.sql.gz	19944
45	2022-09-30 00:00:02.158993+00	2022-09-30 00:00:02.38431+00	t	/home/claire/Backup/bdd/20220930-000002-bdd.sql.gz	19971
46	2022-10-01 00:00:02.707139+00	2022-10-01 00:00:02.946676+00	t	/home/claire/Backup/bdd/20221001-000002-bdd.sql.gz	20086
47	2022-10-02 00:00:02.089828+00	2022-10-02 00:00:02.332149+00	t	/home/claire/Backup/bdd/20221002-000002-bdd.sql.gz	20118
48	2022-10-03 00:00:02.601556+00	2022-10-03 00:00:02.82137+00	t	/home/claire/Backup/bdd/20221003-000002-bdd.sql.gz	20341
49	2022-10-04 00:00:02.021471+00	2022-10-04 00:00:02.245177+00	t	/home/claire/Backup/bdd/20221004-000002-bdd.sql.gz	21089
50	2022-10-05 00:00:02.402791+00	2022-10-05 00:00:02.651705+00	t	/home/claire/Backup/bdd/20221005-000002-bdd.sql.gz	21114
51	2022-10-06 00:00:01.854206+00	2022-10-06 00:00:02.096506+00	t	/home/claire/Backup/bdd/20221006-000001-bdd.sql.gz	21577
52	2022-10-07 00:00:02.258817+00	2022-10-07 00:00:02.478933+00	t	/home/claire/Backup/bdd/20221007-000002-bdd.sql.gz	21704
22	2022-09-07 00:00:02.242279+00	2022-09-07 00:00:02.490333+00	t	/home/claire/Backup/bdd/20220907-000002-bdd.sql.gz	12959
23	2022-09-08 00:00:02.626809+00	2022-09-08 00:00:02.83501+00	t	/home/claire/Backup/bdd/20220908-000002-bdd.sql.gz	13688
24	2022-09-09 00:00:01.915782+00	2022-09-09 00:00:02.152714+00	t	/home/claire/Backup/bdd/20220909-000001-bdd.sql.gz	15395
25	2022-09-10 00:00:02.285521+00	2022-09-10 00:00:02.532128+00	t	/home/claire/Backup/bdd/20220910-000002-bdd.sql.gz	16129
26	2022-09-11 00:00:02.610985+00	2022-09-11 00:00:02.86709+00	t	/home/claire/Backup/bdd/20220911-000002-bdd.sql.gz	17379
27	2022-09-12 00:00:02.044445+00	2022-09-12 00:00:02.268529+00	t	/home/claire/Backup/bdd/20220912-000002-bdd.sql.gz	18405
28	2022-09-13 00:00:02.435077+00	2022-09-13 00:00:02.672199+00	t	/home/claire/Backup/bdd/20220913-000002-bdd.sql.gz	18426
29	2022-09-14 00:00:01.711033+00	2022-09-14 00:00:01.946491+00	t	/home/claire/Backup/bdd/20220914-000001-bdd.sql.gz	18235
30	2022-09-15 00:00:02.050981+00	2022-09-15 00:00:02.281857+00	t	/home/claire/Backup/bdd/20220915-000002-bdd.sql.gz	18270
31	2022-09-16 00:00:02.373374+00	2022-09-16 00:00:02.59936+00	t	/home/claire/Backup/bdd/20220916-000002-bdd.sql.gz	18300
32	2022-09-17 00:00:01.769+00	2022-09-17 00:00:02.015506+00	t	/home/claire/Backup/bdd/20220917-000001-bdd.sql.gz	19103
33	2022-09-18 00:00:02.150864+00	2022-09-18 00:00:02.408218+00	t	/home/claire/Backup/bdd/20220918-000002-bdd.sql.gz	19131
53	2022-10-08 00:00:02.674447+00	2022-10-08 00:00:02.902496+00	t	/home/claire/Backup/bdd/20221008-000002-bdd.sql.gz	21942
54	2022-10-09 00:00:02.082533+00	2022-10-09 00:00:02.345237+00	t	/home/claire/Backup/bdd/20221009-000002-bdd.sql.gz	22405
55	2022-10-10 00:00:02.462081+00	2022-10-10 00:00:02.726357+00	t	/home/claire/Backup/bdd/20221010-000002-bdd.sql.gz	22436
56	2022-10-11 00:00:02.044203+00	2022-10-11 00:00:02.263779+00	t	/home/claire/Backup/bdd/20221011-000002-bdd.sql.gz	22788
57	2022-10-12 00:00:02.147293+00	2022-10-12 00:00:02.380281+00	t	/home/claire/Backup/bdd/20221012-000002-bdd.sql.gz	22971
58	2022-10-13 00:00:02.082546+00	2022-10-13 00:00:02.295589+00	t	/home/claire/Backup/bdd/20221013-000002-bdd.sql.gz	23003
59	2022-10-14 00:00:01.880974+00	2022-10-14 00:00:02.107727+00	t	/home/claire/Backup/bdd/20221014-000001-bdd.sql.gz	23190
60	2022-10-15 00:00:02.587759+00	2022-10-15 00:00:02.841165+00	t	/home/claire/Backup/bdd/20221015-000002-bdd.sql.gz	23434
61	2022-10-16 00:00:02.430846+00	\N	\N		\N
\.


--
-- Name: admin_interface_theme_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.admin_interface_theme_id_seq', 2, true);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 2, true);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 46, true);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 76, true);


--
-- Name: authentification_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.authentification_user_groups_id_seq', 4, true);


--
-- Name: authentification_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.authentification_user_id_seq', 6, true);


--
-- Name: authentification_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.authentification_user_user_permissions_id_seq', 1, false);


--
-- Name: bdd_affaire_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.bdd_affaire_id_seq', 5, true);


--
-- Name: bdd_attachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.bdd_attachment_id_seq', 19, true);


--
-- Name: bdd_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.bdd_client_id_seq', 28, true);


--
-- Name: bdd_compteur_indice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.bdd_compteur_indice_id_seq', 12, true);


--
-- Name: bdd_envoi_facture_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.bdd_envoi_facture_id_seq', 5, true);


--
-- Name: bdd_envoi_offre_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.bdd_envoi_offre_id_seq', 4, true);


--
-- Name: bdd_facture_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.bdd_facture_id_seq', 4, true);


--
-- Name: bdd_infoemail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.bdd_infoemail_id_seq', 10, true);


--
-- Name: bdd_ingeprev_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.bdd_ingeprev_id_seq', 1, true);


--
-- Name: bdd_offre_mission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.bdd_offre_mission_id_seq', 27, true);


--
-- Name: bdd_pilote_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.bdd_pilote_id_seq', 3, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 189, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 19, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 67, true);


--
-- Name: processes_logbackup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: claire
--

SELECT pg_catalog.setval('public.processes_logbackup_id_seq', 61, true);


--
-- Name: admin_interface_theme admin_interface_theme_name_30bda70f_uniq; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.admin_interface_theme
    ADD CONSTRAINT admin_interface_theme_name_30bda70f_uniq UNIQUE (name);


--
-- Name: admin_interface_theme admin_interface_theme_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.admin_interface_theme
    ADD CONSTRAINT admin_interface_theme_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: authentification_user_groups authentification_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.authentification_user_groups
    ADD CONSTRAINT authentification_user_groups_pkey PRIMARY KEY (id);


--
-- Name: authentification_user_groups authentification_user_groups_user_id_group_id_8756f2ae_uniq; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.authentification_user_groups
    ADD CONSTRAINT authentification_user_groups_user_id_group_id_8756f2ae_uniq UNIQUE (user_id, group_id);


--
-- Name: authentification_user authentification_user_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.authentification_user
    ADD CONSTRAINT authentification_user_pkey PRIMARY KEY (id);


--
-- Name: authentification_user_user_permissions authentification_user_us_user_id_permission_id_0505c2b8_uniq; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.authentification_user_user_permissions
    ADD CONSTRAINT authentification_user_us_user_id_permission_id_0505c2b8_uniq UNIQUE (user_id, permission_id);


--
-- Name: authentification_user_user_permissions authentification_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.authentification_user_user_permissions
    ADD CONSTRAINT authentification_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: authentification_user authentification_user_username_key; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.authentification_user
    ADD CONSTRAINT authentification_user_username_key UNIQUE (username);


--
-- Name: bdd_affaire bdd_affaire_ID_Mission_id_key; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_affaire
    ADD CONSTRAINT "bdd_affaire_ID_Mission_id_key" UNIQUE ("ID_Mission_id");


--
-- Name: bdd_affaire bdd_affaire_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_affaire
    ADD CONSTRAINT bdd_affaire_pkey PRIMARY KEY (id);


--
-- Name: bdd_attachment bdd_attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_attachment
    ADD CONSTRAINT bdd_attachment_pkey PRIMARY KEY (id);


--
-- Name: bdd_client bdd_client_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_client
    ADD CONSTRAINT bdd_client_pkey PRIMARY KEY (id);


--
-- Name: bdd_compteur_indice bdd_compteur_indice_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_compteur_indice
    ADD CONSTRAINT bdd_compteur_indice_pkey PRIMARY KEY (id);


--
-- Name: bdd_envoi_facture bdd_envoi_facture_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_envoi_facture
    ADD CONSTRAINT bdd_envoi_facture_pkey PRIMARY KEY (id);


--
-- Name: bdd_envoi_offre bdd_envoi_offre_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_envoi_offre
    ADD CONSTRAINT bdd_envoi_offre_pkey PRIMARY KEY (id);


--
-- Name: bdd_facture bdd_facture_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_facture
    ADD CONSTRAINT bdd_facture_pkey PRIMARY KEY (id);


--
-- Name: bdd_infoemail bdd_infoemail_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_infoemail
    ADD CONSTRAINT bdd_infoemail_pkey PRIMARY KEY (id);


--
-- Name: bdd_ingeprev bdd_ingeprev_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_ingeprev
    ADD CONSTRAINT bdd_ingeprev_pkey PRIMARY KEY (id);


--
-- Name: bdd_offre_mission bdd_offre_mission_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_offre_mission
    ADD CONSTRAINT bdd_offre_mission_pkey PRIMARY KEY (id);


--
-- Name: bdd_pilote bdd_pilote_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_pilote
    ADD CONSTRAINT bdd_pilote_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: processes_logbackup processes_logbackup_pkey; Type: CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.processes_logbackup
    ADD CONSTRAINT processes_logbackup_pkey PRIMARY KEY (id);


--
-- Name: admin_interface_theme_name_30bda70f_like; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX admin_interface_theme_name_30bda70f_like ON public.admin_interface_theme USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: authentification_user_groups_group_id_81eeee0f; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX authentification_user_groups_group_id_81eeee0f ON public.authentification_user_groups USING btree (group_id);


--
-- Name: authentification_user_groups_user_id_43be5d3c; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX authentification_user_groups_user_id_43be5d3c ON public.authentification_user_groups USING btree (user_id);


--
-- Name: authentification_user_user_permissions_permission_id_62750d9c; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX authentification_user_user_permissions_permission_id_62750d9c ON public.authentification_user_user_permissions USING btree (permission_id);


--
-- Name: authentification_user_user_permissions_user_id_576a50aa; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX authentification_user_user_permissions_user_id_576a50aa ON public.authentification_user_user_permissions USING btree (user_id);


--
-- Name: authentification_user_username_e9ac7af7_like; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX authentification_user_username_e9ac7af7_like ON public.authentification_user USING btree (username varchar_pattern_ops);


--
-- Name: bdd_affaire_ID_Client_Cache_id_50a7cf03; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX "bdd_affaire_ID_Client_Cache_id_50a7cf03" ON public.bdd_affaire USING btree ("ID_Client_Cache_id");


--
-- Name: bdd_affaire_ID_Envoi_Facture_id_3f4a733f; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX "bdd_affaire_ID_Envoi_Facture_id_3f4a733f" ON public.bdd_affaire USING btree ("ID_Envoi_Facture_id");


--
-- Name: bdd_affaire_ID_Payeur_id_3ba1e676; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX "bdd_affaire_ID_Payeur_id_3ba1e676" ON public.bdd_affaire USING btree ("ID_Payeur_id");


--
-- Name: bdd_affaire_ID_Pilote_id_204ca049; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX "bdd_affaire_ID_Pilote_id_204ca049" ON public.bdd_affaire USING btree ("ID_Pilote_id");


--
-- Name: bdd_attachment_message_id_2ca94af5; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX bdd_attachment_message_id_2ca94af5 ON public.bdd_attachment USING btree (message_id);


--
-- Name: bdd_facture_ID_Affaire_id_8fe15339; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX "bdd_facture_ID_Affaire_id_8fe15339" ON public.bdd_facture USING btree ("ID_Affaire_id");


--
-- Name: bdd_facture_ID_Envoi_Facture_id_2654abae; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX "bdd_facture_ID_Envoi_Facture_id_2654abae" ON public.bdd_facture USING btree ("ID_Envoi_Facture_id");


--
-- Name: bdd_facture_ID_Payeur_id_9fd40a15; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX "bdd_facture_ID_Payeur_id_9fd40a15" ON public.bdd_facture USING btree ("ID_Payeur_id");


--
-- Name: bdd_facture_ID_Pilote_id_47f36e4c; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX "bdd_facture_ID_Pilote_id_47f36e4c" ON public.bdd_facture USING btree ("ID_Pilote_id");


--
-- Name: bdd_offre_mission_ID_Apporteur_id_9d5f4cf9; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX "bdd_offre_mission_ID_Apporteur_id_9d5f4cf9" ON public.bdd_offre_mission USING btree ("ID_Apporteur_id");


--
-- Name: bdd_offre_mission_ID_Client_Cache_id_187906e8; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX "bdd_offre_mission_ID_Client_Cache_id_187906e8" ON public.bdd_offre_mission USING btree ("ID_Client_Cache_id");


--
-- Name: bdd_offre_mission_ID_Envoi_Offre_id_2cb72fb7; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX "bdd_offre_mission_ID_Envoi_Offre_id_2cb72fb7" ON public.bdd_offre_mission USING btree ("ID_Envoi_Offre_id");


--
-- Name: bdd_offre_mission_ID_Payeur_id_375cbcda; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX "bdd_offre_mission_ID_Payeur_id_375cbcda" ON public.bdd_offre_mission USING btree ("ID_Payeur_id");


--
-- Name: bdd_offre_mission_ID_Pilote_id_99f630fd; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX "bdd_offre_mission_ID_Pilote_id_99f630fd" ON public.bdd_offre_mission USING btree ("ID_Pilote_id");


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: claire
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authentification_user_user_permissions authentification_use_permission_id_62750d9c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.authentification_user_user_permissions
    ADD CONSTRAINT authentification_use_permission_id_62750d9c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authentification_user_groups authentification_use_user_id_43be5d3c_fk_authentif; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.authentification_user_groups
    ADD CONSTRAINT authentification_use_user_id_43be5d3c_fk_authentif FOREIGN KEY (user_id) REFERENCES public.authentification_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authentification_user_user_permissions authentification_use_user_id_576a50aa_fk_authentif; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.authentification_user_user_permissions
    ADD CONSTRAINT authentification_use_user_id_576a50aa_fk_authentif FOREIGN KEY (user_id) REFERENCES public.authentification_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authentification_user_groups authentification_user_groups_group_id_81eeee0f_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.authentification_user_groups
    ADD CONSTRAINT authentification_user_groups_group_id_81eeee0f_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bdd_affaire bdd_affaire_ID_Client_Cache_id_50a7cf03_fk_bdd_client_id; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_affaire
    ADD CONSTRAINT "bdd_affaire_ID_Client_Cache_id_50a7cf03_fk_bdd_client_id" FOREIGN KEY ("ID_Client_Cache_id") REFERENCES public.bdd_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bdd_affaire bdd_affaire_ID_Envoi_Facture_id_3f4a733f_fk_bdd_envoi; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_affaire
    ADD CONSTRAINT "bdd_affaire_ID_Envoi_Facture_id_3f4a733f_fk_bdd_envoi" FOREIGN KEY ("ID_Envoi_Facture_id") REFERENCES public.bdd_envoi_facture(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bdd_affaire bdd_affaire_ID_Mission_id_60c9923a_fk_bdd_offre_mission_id; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_affaire
    ADD CONSTRAINT "bdd_affaire_ID_Mission_id_60c9923a_fk_bdd_offre_mission_id" FOREIGN KEY ("ID_Mission_id") REFERENCES public.bdd_offre_mission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bdd_affaire bdd_affaire_ID_Payeur_id_3ba1e676_fk_bdd_client_id; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_affaire
    ADD CONSTRAINT "bdd_affaire_ID_Payeur_id_3ba1e676_fk_bdd_client_id" FOREIGN KEY ("ID_Payeur_id") REFERENCES public.bdd_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bdd_affaire bdd_affaire_ID_Pilote_id_204ca049_fk_bdd_pilote_id; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_affaire
    ADD CONSTRAINT "bdd_affaire_ID_Pilote_id_204ca049_fk_bdd_pilote_id" FOREIGN KEY ("ID_Pilote_id") REFERENCES public.bdd_pilote(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bdd_attachment bdd_attachment_message_id_2ca94af5_fk_bdd_infoemail_id; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_attachment
    ADD CONSTRAINT bdd_attachment_message_id_2ca94af5_fk_bdd_infoemail_id FOREIGN KEY (message_id) REFERENCES public.bdd_infoemail(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bdd_facture bdd_facture_ID_Affaire_id_8fe15339_fk_bdd_affaire_id; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_facture
    ADD CONSTRAINT "bdd_facture_ID_Affaire_id_8fe15339_fk_bdd_affaire_id" FOREIGN KEY ("ID_Affaire_id") REFERENCES public.bdd_affaire(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bdd_facture bdd_facture_ID_Envoi_Facture_id_2654abae_fk_bdd_envoi; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_facture
    ADD CONSTRAINT "bdd_facture_ID_Envoi_Facture_id_2654abae_fk_bdd_envoi" FOREIGN KEY ("ID_Envoi_Facture_id") REFERENCES public.bdd_envoi_facture(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bdd_facture bdd_facture_ID_Payeur_id_9fd40a15_fk_bdd_client_id; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_facture
    ADD CONSTRAINT "bdd_facture_ID_Payeur_id_9fd40a15_fk_bdd_client_id" FOREIGN KEY ("ID_Payeur_id") REFERENCES public.bdd_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bdd_facture bdd_facture_ID_Pilote_id_47f36e4c_fk_bdd_pilote_id; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_facture
    ADD CONSTRAINT "bdd_facture_ID_Pilote_id_47f36e4c_fk_bdd_pilote_id" FOREIGN KEY ("ID_Pilote_id") REFERENCES public.bdd_pilote(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bdd_offre_mission bdd_offre_mission_ID_Apporteur_id_9d5f4cf9_fk_bdd_client_id; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_offre_mission
    ADD CONSTRAINT "bdd_offre_mission_ID_Apporteur_id_9d5f4cf9_fk_bdd_client_id" FOREIGN KEY ("ID_Apporteur_id") REFERENCES public.bdd_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bdd_offre_mission bdd_offre_mission_ID_Client_Cache_id_187906e8_fk_bdd_client_id; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_offre_mission
    ADD CONSTRAINT "bdd_offre_mission_ID_Client_Cache_id_187906e8_fk_bdd_client_id" FOREIGN KEY ("ID_Client_Cache_id") REFERENCES public.bdd_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bdd_offre_mission bdd_offre_mission_ID_Envoi_Offre_id_2cb72fb7_fk_bdd_envoi; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_offre_mission
    ADD CONSTRAINT "bdd_offre_mission_ID_Envoi_Offre_id_2cb72fb7_fk_bdd_envoi" FOREIGN KEY ("ID_Envoi_Offre_id") REFERENCES public.bdd_envoi_offre(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bdd_offre_mission bdd_offre_mission_ID_Payeur_id_375cbcda_fk_bdd_client_id; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_offre_mission
    ADD CONSTRAINT "bdd_offre_mission_ID_Payeur_id_375cbcda_fk_bdd_client_id" FOREIGN KEY ("ID_Payeur_id") REFERENCES public.bdd_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bdd_offre_mission bdd_offre_mission_ID_Pilote_id_99f630fd_fk_bdd_pilote_id; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.bdd_offre_mission
    ADD CONSTRAINT "bdd_offre_mission_ID_Pilote_id_99f630fd_fk_bdd_pilote_id" FOREIGN KEY ("ID_Pilote_id") REFERENCES public.bdd_pilote(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_authentification_user_id; Type: FK CONSTRAINT; Schema: public; Owner: claire
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_authentification_user_id FOREIGN KEY (user_id) REFERENCES public.authentification_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

